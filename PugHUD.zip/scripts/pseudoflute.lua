local mainImage = "images/0047.png"
local pickleImage = "images/Pickle.png"

local overlayCheck = "overlay|images/checkmark.png"
local overlayCheckOff = "overlay|images/checkmark.png, @disabled"
local overlayOff = "@disabled"

PseudoFluteItem = CustomItem:extend()

function PseudoFluteItem:init(name, code)
	self:createItem(name) 
	self.code = code
    self.count = 0
	self.currentImage = mainIMage
	self.ItemInstance.PotentialIcon = ImageReference:FromPackRelativePath(self.currentImage)
	self.currentOverlay = ""
	self.badged = false
	self:updateIcon()
end

function PseudoFluteItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function PseudoFluteItem:providesCode(code)
    if code == self.code then
        return 1
    end
    return 0
end

function PseudoFluteItem:onLeftClick()
	if self.count == 1 then
		self.count = 0
	else
		self.count = 1
	end
	self:updateIcon()
end

function PseudoFluteItem:setCount(value)
	self.count = value
	self:updateIcon()
end

function PseudoFluteItem:onRightClick()
	self.badged = not self.badged
	self:updateIcon()
end

function PseudoFluteItem:updateIcon()
	if self.badged then
		print("counter: " .. self.count .. ", true")
	else
		print("counter: " .. self.count .. ", false")
	end

	if self.count == 0 and self.badged then
		self.currentOverlay = overlayCheckOff
	elseif self.count == 0 then
		self.currentOverlay = overlayOff
	elseif self.badged then
		self.currentOverlay = overlayCheck
	else
		self.currentOverlay = ""
	end

	if self.count == 2 then
		self.currentImage = pickleImage
	else
		self.currentImage = mainImage
	end
	self.ItemInstance.Icon = ImageReference:FromPackRelativePath(self.currentImage,  self.currentOverlay)
end

function PseudoFluteItem:save()
	local saveData = {
		["badged"] = self.badged,
		["count"] = self.count,
	}
	return saveData
end

function PseudoFluteItem:load(data)
	if data ~= nil then
		self.badged = data["badged"]
		self.count = data["counter"]
		self:updateIcon()
	end
	return true
end