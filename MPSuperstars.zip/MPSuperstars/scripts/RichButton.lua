local p10image = "images/plus10.png"
local p3image = "images/plus3.png"
local p2image = "images/plus2.png"
local m2image = "images/minus2.png"
local m3image = "images/minus3.png"
local m10image = "images/minus10.png"

RichButton = class(CustomItem)

function RichButton:init(name, code, value, player)
	self:createItem(name) 
	self.code = code
	self.value = value
	self.player = player
    self:setProperty("active", true)
	if value == 10 then
		self.currentImage = p10image
	elseif value == 3 then
		self.currentImage = p3image
	elseif value == 2 then
		self.currentImage = p2image
	elseif value == -2 then
		self.currentImage = m2image
	elseif value == -3 then
		self.currentImage = m3image
	elseif value == -10 then
		self.currentImage = m10image
	else
		self.currentImage = p10image
	end
	self.ItemInstance.PotentialIcon = ImageReference:FromPackRelativePath(self.currentImage)
	self:updateIcon()
end

function RichButton:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function RichButton:providesCode(code)
    if code == self.code then
        return 1
    end
    return 0
end

function RichButton:onLeftClick()
end

function RichButton:onRightClick()
end

function RichButton:updateIcon()
	if self.value == 10 then
		self.currentImage = p10image
	elseif self.value == 3 then
		self.currentImage = p3image
	elseif self.value == 2 then
		self.currentImage = p2image
	elseif self.value == -2 then
		self.currentImage = m2image
	elseif self.value == -3 then
		self.currentImage = m3image
	elseif self.value == -10 then
		self.currentImage = m10image
	else
		self.currentImage = p10image
	end
	self.ItemInstance.Icon = ImageReference:FromPackRelativePath(self.currentImage, self.currentOverlay)
end