local clearImage = "images/clear.png"

ClearButton = CustomItem:extend()

function ClearButton:init(name, code)
	self:createItem(name) 
	self.code = code
	self.currentImage = clearImage
	self.ItemInstance.Icon = ImageReference:FromPackRelativePath(self.currentImage)
    self:setProperty("active", true)
	self:updateIcon()
end

function ClearButton:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function ClearButton:providesCode(code)
    if code == self.code then
        return 1
    end
    return 0
end

function ClearButton:onLeftClick()
	for i=1, 4
	do
		richCount = Tracker:FindObjectForCode("p" .. i .. "c").ItemState
		richCount.count = 0
		richCount:updateIcon()
		happeningCount = Tracker:FindObjectForCode("p" .. i .. "h")
		happeningCount.CurrentStage = 0
		minigameCount = Tracker:FindObjectForCode("p" .. i .. "vs")
		minigameCount.CurrentStage = 0
	end
end

function ClearButton:onRightClick()
end

function ClearButton:updateIcon()
end