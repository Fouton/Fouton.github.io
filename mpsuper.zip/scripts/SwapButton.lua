local leftImage = "images/left.png"
local rightImage = "images/right.png"
local upImage = "images/up.png"
local downImage = "images/down.png"

SwapButton = CustomItem:extend()

function SwapButton:init(name, code, player, direction)
	self:createItem(name) 
	self.code = code
	self.player = player
	self.direction = direction
    self:setProperty("active", true)
	self:updateIcon()
end

function SwapButton:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function SwapButton:providesCode(code)
    if code == self.code then
        return 1
    end
    return 0
end

function SwapButton:onLeftClick()
	richCount = Tracker:FindObjectForCode("p" .. self.player .. "c").ItemState
	happeningCount = Tracker:FindObjectForCode("p" .. self.player .. "h").ItemState
	minigameCount = Tracker:FindObjectForCode("p" .. self.player .. "vs").ItemState
	playerIcon = Tracker:FindObjectForCode("p" .. self.player .. "")
	if self.direction == "left" then
		otherPlayer = self.player - 1
		if otherPlayer == 0 then
			otherPlayer = 4
		end
	else
		otherPlayer = self.player + 1
		if otherPlayer == 5 then
			otherPlayer = 1
		end
	end
	richCountOther = Tracker:FindObjectForCode("p" .. otherPlayer .. "c").ItemState
	happeningCountOther = Tracker:FindObjectForCode("p" .. otherPlayer .. "h").ItemState
	minigameCountOther = Tracker:FindObjectForCode("p" .. otherPlayer .. "vs").ItemState
	playerIconOther = Tracker:FindObjectForCode("p" .. otherPlayer .. "")

	richHolder = richCount.count
	happeningHolder = happeningCount.count
	minigameHolder = minigameCount.count
	playerHolder = playerIcon.CurrentStage + self.player - otherPlayer
	if playerHolder > 9 then
		playerHolder = playerHolder - 10
	elseif playerHolder < 0 then
		playerHolder = playerHolder + 10
	end

	otherPlayerHolder = playerIconOther.CurrentStage + otherPlayer - self.player
	if otherPlayerHolder > 9 then
		otherPlayerHolder = otherPlayerHolder - 10
	elseif otherPlayerHolder < 0 then
		otherPlayerHolder = otherPlayerHolder + 10
	end

	richCount.count = richCountOther.count
	happeningCount.count = happeningCountOther.count
	minigameCount.count = minigameCountOther.count
	playerIcon.CurrentStage = otherPlayerHolder

	richCountOther.count = richHolder
	happeningCountOther.count = happeningHolder
	minigameCountOther.count = minigameHolder
	playerIconOther.CurrentStage = playerHolder

    richCount:updateIcon()
    richCountOther:updateIcon()
    happeningCount:updateIcon()
    happeningCountOther:updateIcon()
    minigameCount:updateIcon()
    minigameCountOther:updateIcon()
end

function SwapButton:onRightClick()
end

function SwapButton:updateIcon()
	if self.direction == "left" and string.find(Tracker.ActiveVariantUID, "horizontal") then
		self.currentImage = upImage
	elseif self.direction == "left" then
		self.currentImage = leftImage
	elseif string.find(Tracker.ActiveVariantUID, "horizontal") then
		self.currentImage = downImage
	else
		self.currentImage = rightImage
	end
	self.ItemInstance.Icon = ImageReference:FromPackRelativePath(self.currentImage)
end