-- Configuration --------------------------------------
AUTOTRACKER_ENABLE_DEBUG_LOGGING = false
-------------------------------------------------------

print("")
print("Active Auto-Tracker Configuration")
print("---------------------------------------------------------------------")
print("Enable Item Tracking:        ", AUTOTRACKER_ENABLE_ITEM_TRACKING)
print("Enable Location Tracking:    ", AUTOTRACKER_ENABLE_LOCATION_TRACKING)
if AUTOTRACKER_ENABLE_DEBUG_LOGGING then
    print("Enable Debug Logging:        ", "true")
end
print("---------------------------------------------------------------------")
print("")

function autotracker_started()
    -- Invoked when the auto-tracker is activated/connected
end
--woopsyIbrokeeverything --delete me for sd2snes functionality ;)
AUTOTRACKER_IS_IN_GAME = false
AUTOTRACKER_IS_IN_SM = true
AUTOTRACKER_IS_IN_GAME_SM = false
AUTOTRACKER_IS_IN_LTTP = false

U8_READ_CACHE = 0
U8_READ_CACHE_ADDRESS = 0

U16_READ_CACHE = 0
U16_READ_CACHE_ADDRESS = 0

SAVED_SWORD = 0
SAVED_GLOVES = 0
SAVED_BOTTLES = 0
SAVED_HOOKSHOT = false
SAVED_FIREROD = false
SAVED_ICEROD = false
SAVED_BOMBOS = false
SAVED_ETHER = false
SAVED_QUAKE = false
SAVED_LAMP = false
SAVED_HAMMER = false
SAVED_BOOK = false
SAVED_SOMARIA = false
SAVED_BYRNA = false
SAVED_CAPE = false
SAVED_MIRROR = false
SAVED_BOOTS = false
SAVED_FLIPPERS = false
SAVED_PEARL = false
SAVED_HALFMAGIC = false
SAVED_BLUEBOOM = false
SAVED_REDBOOM = false
SAVED_POWDER = false
SAVED_BOW = false
SAVED_SILVERS = false
SAVED_MUSHROOM = false
SAVED_SHOVEL = false
SAVED_FLUTE = false
SAVED_AGA1 = false

function InvalidateReadCaches()
    U8_READ_CACHE_ADDRESS = 0
    U16_READ_CACHE_ADDRESS = 0
end

function ReadU8(segment, address)
    if U8_READ_CACHE_ADDRESS ~= address then
        U8_READ_CACHE = segment:ReadUInt8(address)
        U8_READ_CACHE_ADDRESS = address        
    end

    return U8_READ_CACHE
end

function ReadU16(segment, address)
    if U16_READ_CACHE_ADDRESS ~= address then
        U16_READ_CACHE = segment:ReadUInt16(address)
        U16_READ_CACHE_ADDRESS = address        
    end

    return U16_READ_CACHE
end

function updateGame(segment)
    InvalidateReadCaches()
    local address = 0x7033fe
    if AutoTracker.SelectedConnectorType.Name ~= 'SD2SNES' then
        address = address + 0x314000
    end
    if (ReadU8(segment, address) == 0xFF) then
        if AUTOTRACKER_IS_IN_LTTP then
            runItemSaving()
        end
        AUTOTRACKER_IS_IN_SM = true
        AUTOTRACKER_IS_IN_LTTP = false
    elseif (ReadU8(segment, address) == 0x00) then
        AUTOTRACKER_IS_IN_SM = false
        AUTOTRACKER_IS_IN_LTTP = true
    else
        AUTOTRACKER_IS_IN_SM = false
        AUTOTRACKER_IS_IN_LTTP = false
        print(ReadU8(segment, address))
    end
end

function updateInGameStatusFromMemorySegment(segment)
    if not AUTOTRACKER_IS_IN_LTTP then
        return false
    else
        local mainModuleIdx = segment:ReadUInt8(0x7e0010)

        AUTOTRACKER_IS_IN_GAME = (mainModuleIdx > 0x05 and mainModuleIdx ~= 0x17)
        print(mainModuleIdx)
        print(AUTOTRACKER_IS_IN_GAME)
        return true
    end
end

function updateInGameStatusSM(segment)
    if not AUTOTRACKER_IS_IN_SM then
        return false
    else
        local mainModuleIdx = ReadU8(segment, 0x7e0998)
        
        AUTOTRACKER_IS_IN_GAME_SM = (mainModuleIdx == 0x08)
        
        print("SM status?:")
        print(mainModuleIdx)
        return true     
    end
end

function updateToggleFromRoomSlot(segment, code, slot)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local roomData = ReadU16(segment, 0x7ef000 + (slot[1] * 2))
        
        if AUTOTRACKER_ENABLE_DEBUG_LOGGING then
            print(roomData)
        end

        item.Active = (roomData & (1 << slot[2])) ~= 0
    end
end

function updateProgressiveItemFromByte(segment, code, address, offset)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        item.CurrentStage = value + (offset or 0)
    end
end

function saveProgressiveItemFromByte(segment, code, address, offset)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        return value + (offset or 0)
    end
end

function updateAga1(segment)
    local item = Tracker:FindObjectForCode("aga1")
    local value = ReadU8(segment, 0x7ef3c5)
    if value >= 3 then
        item.Active = true
    else
        item.Active = false
    end
end

function saveAga1(segment)
    local item = Tracker:FindObjectForCode("aga1")
    local value = ReadU8(segment, 0x7ef3c5)
    if value >= 3 then
        return true
    else
        return false
    end
end

function updateBottles(segment)
    local item = Tracker:FindObjectForCode("bottle")    
    local count = 0
    for i = 0, 3, 1 do
        if ReadU8(segment, 0x7ef35c + i) > 0 then
            count = count + 1
        end
    end
    item.CurrentStage = count
end

function saveBottles(segment)
    local address = 0x703b5c
    if AutoTracker.SelectedConnectorType.Name ~= 'SD2SNES' then
        address = address + 0x314000
    end
    local count = 0
    for i = 0, 3, 1 do
        if ReadU8(segment, address + i) > 0 then
            count = count + 1
        end
    end
    return count
end

function updateInactiveBottles(segment)
    local address= 0x703b5c
    if AutoTracker.SelectedConnectorType.Name ~= 'SD2SNES' then
        address = address + 0x314000
    end
    local item = Tracker:FindObjectForCode("bottle")    
    local count = 0
    for i = 0, 3, 1 do
        if ReadU8(segment, address + i) > 0 then
            count = count + 1
        end
    end
    item.CurrentStage = count
end

function updateToggleItemFromByte(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if value == 1 then
            item.Active = true
        elseif value == 0 then
            item.Active = false
        end
    end
end

function saveToggleItemFromByte(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if value == 1 then
            return true
        elseif value == 0 then
            return false
        end
    end
end

function updateMirror(segment, address)
    local item = Tracker:FindObjectForCode("mirror")
    if item then
        local value = ReadU8(segment, address)
        if value == 1 or value == 2then
            item.Active = true
        elseif value == 0 then
            item.Active = false
        end
    end
end

function saveMirror(segment, address)
    local item = Tracker:FindObjectForCode("mirror")
    if item then
        local value = ReadU8(segment, address)
        if value == 1 or value == 2then
            return true
        elseif value == 0 then
            return false
        end
    end
end

function updateAmmoFrom2Bytes(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    local value = ReadU8(segment, address+1)*256 + ReadU8(segment, address)
    if item then
        if code == "etank" then
            if value > 1499 then
                item.CurrentStage = 14
            else
                item.CurrentStage = value/100
            end
        elseif code == "reserve" then
            if value > 400 then
                item.CurrentStage = 4
            else
                item.CurrentStage = value/100
            end
        else
            if value > 200 then
                if code == "missile" then
                    item.CurrentStage = 39
                elseif code == "supers" then
                    item.CurrentStage = 19
                elseif code == "pb" then
                    item.CurrentStage = 19
                end
            elseif value > 95 and (code == "supers" or code == "pb") then
                item.CurrentStage = 19
            elseif value > 195 then
                item.CurrentStage = 39
            else
                item.CurrentStage = value/5
            end
        end
    end
end

function updateToggleItemFromByteAndFlag(segment, code, address, flag)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)

        local flagTest = value & flag

        if flagTest ~= 0 then
            item.Active = true
        else
            item.Active = false
        end
        if code == "ridley" or code == "draygon" or code == "kraid" or code == "phantoon" then
            print(item.Name, " ",flagTest)
        end
    end
end

function saveToggleItemFromByteAndFlag(segment, code, address, flag)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if AUTOTRACKER_ENABLE_DEBUG_LOGGING then
            print(item.Name, code, flag)
        end

        local flagTest = value & flag

        if flagTest ~= 0 then
            return true
        else
            return false
        end
    end
end

function updateFlute(segment)
    local item = Tracker:FindObjectForCode("flute")
    local value = ReadU8(segment, 0x7ef38c)

    local fakeFlute = value & 0x02
    local realFlute = value & 0x01

    if realFlute ~= 0 then
        item.Active = true
    elseif fakeFlute ~= 0 then
        item.Active = true
    else
        item.Active = false
    end
end

function saveFlute(segment)
    local address = 0x703b8c
    if AutoTracker.SelectedConnectorType.Name ~= 'SD2SNES' then
        address = address + 0x314000
    end
    local item = Tracker:FindObjectForCode("flute")
    local value = ReadU8(segment, address)

    local fakeFlute = value & 0x02
    local realFlute = value & 0x01

    if realFlute ~= 0 then
        return true
    elseif fakeFlute ~= 0 then
        return true
    else
        return false
    end
end

function updateInactiveFlute(segment)
    local address = 0x703b8c
    if AutoTracker.SelectedConnectorType.Name ~= 'SD2SNES' then
        address = address + 0x314000
    end
    local item = Tracker:FindObjectForCode("flute")
    local value = ReadU8(segment, address)

    local fakeFlute = value & 0x02
    local realFlute = value & 0x01

    if realFlute ~= 0 then
        item.Active = true
    elseif fakeFlute ~= 0 then
        item.Active = true
    else
        item.Active = false
    end
end

function updateItemsFromMemorySegmentActiveLTTP(segment)

    InvalidateReadCaches()    

    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        if AUTOTRACKER_IS_IN_LTTP and AUTOTRACKER_IS_IN_GAME then

            updateProgressiveItemFromByte(segment, "sword",  0x7ef359)
            updateProgressiveItemFromByte(segment, "gloves", 0x7ef354)

            updateToggleItemFromByte(segment, "hookshot",  0x7ef342)
            updateToggleItemFromByte(segment, "firerod",   0x7ef345)
            updateToggleItemFromByte(segment, "icerod",    0x7ef346)
            updateToggleItemFromByte(segment, "bombos",    0x7ef347)
            updateToggleItemFromByte(segment, "ether",     0x7ef348)
            updateToggleItemFromByte(segment, "quake",     0x7ef349)
            updateToggleItemFromByte(segment, "lamp",      0x7ef34a)
            updateToggleItemFromByte(segment, "hammer",    0x7ef34b)
            updateToggleItemFromByte(segment, "book",      0x7ef34e)
            updateToggleItemFromByte(segment, "somaria",   0x7ef350)
            updateToggleItemFromByte(segment, "byrna",     0x7ef351)
            updateToggleItemFromByte(segment, "cape",      0x7ef352)
            updateMirror(segment, 0x7ef353)
            updateToggleItemFromByte(segment, "boots",     0x7ef355)
            updateToggleItemFromByte(segment, "flippers",  0x7ef356)
            updateToggleItemFromByte(segment, "pearl",     0x7ef357)
            updateToggleItemFromByte(segment, "halfmagic", 0x7ef37b)

            updateToggleItemFromByteAndFlag(segment, "blueboom", 0x7ef38c, 0x80)
            updateToggleItemFromByteAndFlag(segment, "redboom",  0x7ef38c, 0x40)
            updateToggleItemFromByteAndFlag(segment, "powder", 0x7ef38c, 0x10)
            updateToggleItemFromByteAndFlag(segment, "bow", 0x7ef38e, 0x80)
            updateToggleItemFromByteAndFlag(segment, "silvers", 0x7ef38e, 0x40)

            updateToggleItemFromByteAndFlag(segment, "mushroom", 0x7ef38c, 0x20)
            updateToggleItemFromByteAndFlag(segment, "shovel", 0x7ef38c, 0x04)

            updateBottles(segment)
            updateFlute(segment)
            return true
        else
            return false
        end
    end
end

function updateRoomsFromMemorySegment(segment)
    if AUTOTRACKER_IS_IN_LTTP and AUTOTRACKER_IS_IN_GAME then
        updateToggleFromRoomSlot(segment, "ep", { 200, 11 })
        updateToggleFromRoomSlot(segment, "dp", { 51, 11 })
        updateToggleFromRoomSlot(segment, "toh", { 7, 11 })
        updateToggleFromRoomSlot(segment, "pod", { 90, 11 })
        updateToggleFromRoomSlot(segment, "sp", { 6, 11 })
        updateToggleFromRoomSlot(segment, "sw", { 41, 11 })
        updateToggleFromRoomSlot(segment, "tt", { 172, 11 })
        updateToggleFromRoomSlot(segment, "ip", { 222, 11 })
        updateToggleFromRoomSlot(segment, "mm", { 144, 11 })
        updateToggleFromRoomSlot(segment, "tr", { 164, 11 })
        return true
    else
        return false
    end
end

function updateLTTPcompletion(segment)
    local address = 0x703506
    if AutoTracker.SelectedConnectorType.Name ~= "SD2SNES" then
        address = address + 0x314000
    end

    if AUTOTRACKER_IS_IN_LTTP then
        local item = Tracker:FindObjectForCode("ganon")
        if (ReadU8(segment, address) == 0x01) then
            item.Active = true
            return true
        end
    else
        return false
    end
end

function updateSMcompletion(segment)
    local address = 0x703403
    if AutoTracker.SelectedConnectorType.Name ~= "SD2SNES" then
        address = address + 0x314000
    end
    if AUTOTRACKER_IS_IN_SM then
        local item = Tracker:FindObjectForCode("brain")
        if (ReadU8(segment, address) == 0x01) then
            item.Active = true
            return true
        end
    else
        return false
    end
end

function updateItemsFromMemorySegmentInactiveLTTP(segment)
    local address = 0x703b00
    if AutoTracker.SelectedConnectorType.Name ~= "SD2SNES" then
        address = address + 0x314000
    end
    
    InvalidateReadCaches()
    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        if AUTOTRACKER_IS_IN_SM then

            updateProgressiveItemFromByte(segment, "sword",  address + 0x59)
            updateProgressiveItemFromByte(segment, "gloves", address + 0x54)

            updateToggleItemFromByte(segment, "hookshot",  address + 0x42)
            updateToggleItemFromByte(segment, "firerod",   address + 0x45)
            updateToggleItemFromByte(segment, "icerod",    address + 0x46)
            updateToggleItemFromByte(segment, "bombos",    address + 0x47)
            updateToggleItemFromByte(segment, "ether",     address + 0x48)
            updateToggleItemFromByte(segment, "quake",     address + 0x49)
            updateToggleItemFromByte(segment, "lamp",      address + 0x4a)
            updateToggleItemFromByte(segment, "hammer",    address + 0x4b)
            updateToggleItemFromByte(segment, "book",      address + 0x4e)
            updateToggleItemFromByte(segment, "somaria",   address + 0x50)
            updateToggleItemFromByte(segment, "byrna",     address + 0x51)
            updateToggleItemFromByte(segment, "cape",      address + 0x52)
            updateMirror(segment, address + 0x53)
            updateToggleItemFromByte(segment, "boots",     address + 0x55)
            updateToggleItemFromByte(segment, "flippers",  address + 0x56)
            updateToggleItemFromByte(segment, "pearl",     address + 0x57)
            updateToggleItemFromByte(segment, "halfmagic", address + 0x7b)

            updateToggleItemFromByteAndFlag(segment, "blueboom", address + 0x8c, 0x80)
            updateToggleItemFromByteAndFlag(segment, "redboom",  address + 0x8c, 0x40)
            updateToggleItemFromByteAndFlag(segment, "powder", address + 0x8c, 0x10)
            updateToggleItemFromByteAndFlag(segment, "bow", address + 0x8e, 0x80)
            updateToggleItemFromByteAndFlag(segment, "silvers", address + 0x8e, 0x40)

            updateToggleItemFromByteAndFlag(segment, "mushroom", address + 0x8c, 0x20)
            updateToggleItemFromByteAndFlag(segment, "shovel", address + 0x8c, 0x04)

            updateInactiveBottles(segment)
            updateInactiveFlute(segment)

            
            SAVED_SWORD = saveProgressiveItemFromByte(segment, "sword",  address + 0x59)
            SAVED_GLOVES = saveProgressiveItemFromByte(segment, "gloves", address + 0x54)

            SAVED_HOOKSHOT = saveToggleItemFromByte(segment, "hookshot",  address + 0x42)
            SAVED_FIREROD = saveToggleItemFromByte(segment, "firerod",   address + 0x45)
            SAVED_ICEROD = saveToggleItemFromByte(segment, "icerod",    address + 0x46)
            SAVED_BOMBOS = saveToggleItemFromByte(segment, "bombos",    address + 0x47)
            SAVED_ETHER = saveToggleItemFromByte(segment, "ether",     address + 0x48)
            SAVED_QUAKE = saveToggleItemFromByte(segment, "quake",     address + 0x49)
            SAVED_LAMP = saveToggleItemFromByte(segment, "lamp",      address + 0x4a)
            SAVED_HAMMER = saveToggleItemFromByte(segment, "hammer",    address + 0x4b)
            SAVED_BOOK = saveToggleItemFromByte(segment, "book",      address + 0x4e)
            SAVED_SOMARIA = saveToggleItemFromByte(segment, "somaria",   address + 0x50)
            SAVED_BYRNA = saveToggleItemFromByte(segment, "byrna",     address + 0x51)
            SAVED_CAPE = saveToggleItemFromByte(segment, "cape",      address + 0x52)
            SAVED_MIRROR = saveMirror(segment, address + 0x53)
            SAVED_BOOTS = saveToggleItemFromByte(segment, "boots",     address + 0x55)
            SAVED_FLIPPERS = saveToggleItemFromByte(segment, "flippers",  address + 0x56)
            SAVED_PEARL = saveToggleItemFromByte(segment, "pearl",     address + 0x57)
            SAVED_HALFMAGIC = saveToggleItemFromByte(segment, "halfmagic", address + 0x7b)

            SAVED_BLUEBOOM = saveToggleItemFromByteAndFlag(segment, "blueboom", address + 0x8c, 0x80)
            SAVED_REDBOOM = saveToggleItemFromByteAndFlag(segment, "redboom",  address + 0x8c, 0x40)
            SAVED_POWDER = saveToggleItemFromByteAndFlag(segment, "powder", address + 0x8c, 0x10)
            SAVED_BOW = saveToggleItemFromByteAndFlag(segment, "bow", address + 0x8e, 0x80)
            SAVED_SILVERS = saveToggleItemFromByteAndFlag(segment, "silvers", address + 0x8e, 0x40)
            SAVED_MUSHROOM = saveToggleItemFromByteAndFlag(segment, "mushroom", address + 0x8c, 0x20)
            SAVED_SHOVEL = saveToggleItemFromByteAndFlag(segment, "shovel", address + 0x8c, 0x04)

            SAVED_BOTTLES = saveBottles(segment)
            SAVED_FLUTE = saveFlute(segment)
            return true
        else
            return false
        end
    end
end

function runItemSaving()
    local sword = Tracker:FindObjectForCode("sword")
    local gloves = Tracker:FindObjectForCode("gloves")
    local hookshot = Tracker:FindObjectForCode("hookshot")
    local firerod = Tracker:FindObjectForCode("firerod")
    local icerod = Tracker:FindObjectForCode("icerod")
    local bombos = Tracker:FindObjectForCode("bombos")
    local ether = Tracker:FindObjectForCode("ether")
    local quake = Tracker:FindObjectForCode("quake")
    local lamp = Tracker:FindObjectForCode("lamp")
    local hammer = Tracker:FindObjectForCode("hammer")
    local book = Tracker:FindObjectForCode("book")
    local somaria = Tracker:FindObjectForCode("somaria")
    local byrna = Tracker:FindObjectForCode("byrna")
    local cape = Tracker:FindObjectForCode("cape")
    local mirror = Tracker:FindObjectForCode("mirror")
    local boots = Tracker:FindObjectForCode("boots")
    local flippers = Tracker:FindObjectForCode("flippers")
    local pearl = Tracker:FindObjectForCode("pearl")
    local halfmagic = Tracker:FindObjectForCode("halfmagic")
    local blueboom = Tracker:FindObjectForCode("blueboom")
    local redboom = Tracker:FindObjectForCode("redboom")
    local powder = Tracker:FindObjectForCode("powder")
    local bow = Tracker:FindObjectForCode("bow")
    local silvers = Tracker:FindObjectForCode("silvers")
    local mushroom = Tracker:FindObjectForCode("mushroom")
    local shovel = Tracker:FindObjectForCode("shovel")
    local bottle = Tracker:FindObjectForCode("bottle")
    local flute = Tracker:FindObjectForCode("flute")
    local aga1 = Tracker:FindObjectForCode("aga1")

    sword.CurrentStage = SAVED_SWORD
    gloves.CurrentStage = SAVED_GLOVES
    hookshot.Active = SAVED_HOOKSHOT
    firerod.Active = SAVED_FIREROD
    icerod.Active = SAVED_ICEROD
    bombos.Active = SAVED_BOMBOS
    ether.Active = SAVED_ETHER
    quake.Active = SAVED_QUAKE
    lamp.Active = SAVED_LAMP
    hammer.Active = SAVED_HAMMER
    book.Active = SAVED_BOOK
    somaria.Active = SAVED_SOMARIA
    byrna.Active = SAVED_BYRNA
    cape.Active = SAVED_CAPE
    mirror.Active = SAVED_MIRROR
    boots.Active = SAVED_BOOTS
    flippers.Active = SAVED_FLIPPERS
    pearl.Active = SAVED_PEARL
    halfmagic.Active = SAVED_HALFMAGIC
    blueboom.Active = SAVED_BLUEBOOM
    redboom.Active = SAVED_REDBOOM
    powder.Active = SAVED_POWDER
    bow.Active = SAVED_BOW
    silvers.Active = SAVED_SILVERS
    mushroom.Active = SAVED_MUSHROOM
    shovel.Active = SAVED_SHOVEL
    bottle.CurrentStage = SAVED_BOTTLES
    flute.Active = SAVED_FLUTE
    aga1.Active = SAVED_AGA1
end

function updateItemsFromMemorySegmentActiveSM(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        if AUTOTRACKER_IS_IN_SM and AUTOTRACKER_IS_IN_GAME_SM then

            updateToggleItemFromByteAndFlag(segment, "varia", 0x7E09A4, 0x01)
            updateToggleItemFromByteAndFlag(segment, "springball", 0x7E09A4, 0x02)
            updateToggleItemFromByteAndFlag(segment, "morph", 0x7E09A4, 0x04)
            updateToggleItemFromByteAndFlag(segment, "screw", 0x7E09A4, 0x08)
            updateToggleItemFromByteAndFlag(segment, "gravity", 0x7E09A4, 0x20)

            updateToggleItemFromByteAndFlag(segment, "hijump", 0x7E09A5, 0x01)
            updateToggleItemFromByteAndFlag(segment, "spacejump", 0x7E09A5, 0x02)
            updateToggleItemFromByteAndFlag(segment, "bomb", 0x7E09A5, 0x10)
            updateToggleItemFromByteAndFlag(segment, "speedbooster", 0x7E09A5, 0x20)
            updateToggleItemFromByteAndFlag(segment, "grapple", 0x7E09A5, 0x40)
            updateToggleItemFromByteAndFlag(segment, "xray", 0x7E09A5, 0x80)

            updateToggleItemFromByteAndFlag(segment, "wave", 0x7E09A8, 0x01)
            updateToggleItemFromByteAndFlag(segment, "ibeam", 0x7E09A8, 0x02)
            updateToggleItemFromByteAndFlag(segment, "spazer", 0x7E09A8, 0x04)
            updateToggleItemFromByteAndFlag(segment, "plasma", 0x7E09A8, 0x08)
            updateToggleItemFromByteAndFlag(segment, "charge", 0x7E09A9, 0x10)
            return true
        else
            return false
        end
    end
end

function updateItemsFromMemorySegmentInactiveSM(segment)
    InvalidateReadCaches()
    local address = 0x703900
    if AutoTracker.SelectedConnectorType.Name ~= "SD2SNES" then
        address = address + 0x314000
    end

    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        if AUTOTRACKER_IS_IN_LTTP and AUTOTRACKER_IS_IN_GAME then
            updateToggleItemFromByteAndFlag(segment, "varia", address + 0x02, 0x01)
            updateToggleItemFromByteAndFlag(segment, "springball", address + 0x02, 0x02)
            updateToggleItemFromByteAndFlag(segment, "morph", address + 0x02, 0x04)
            updateToggleItemFromByteAndFlag(segment, "screw", address + 0x02, 0x08)
            updateToggleItemFromByteAndFlag(segment, "gravity", address + 0x02, 0x20)

            updateToggleItemFromByteAndFlag(segment, "hijump", address + 0x03, 0x01)
            updateToggleItemFromByteAndFlag(segment, "spacejump", address + 0x03, 0x02)
            updateToggleItemFromByteAndFlag(segment, "bomb", address + 0x03, 0x10)
            updateToggleItemFromByteAndFlag(segment, "speedbooster", address + 0x03, 0x20)
            updateToggleItemFromByteAndFlag(segment, "grapple", address + 0x03, 0x40)
            updateToggleItemFromByteAndFlag(segment, "xray", address + 0x03, 0x80)

            updateToggleItemFromByteAndFlag(segment, "wave", address + 0x06, 0x01)
            updateToggleItemFromByteAndFlag(segment, "ibeam", address + 0x06, 0x02)
            updateToggleItemFromByteAndFlag(segment, "spazer", address + 0x06, 0x04)
            updateToggleItemFromByteAndFlag(segment, "plasma", address + 0x06, 0x08)
            updateToggleItemFromByteAndFlag(segment, "charge", address + 0x07, 0x10)
            return true
        else
            return false
        end
    end
end

function updateAmmoFromMemorySegmentActiveSM(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        if AUTOTRACKER_IS_IN_SM and AUTOTRACKER_IS_IN_GAME_SM then
            updateAmmoFrom2Bytes(segment, "etank", 0x7e09c4)
            updateAmmoFrom2Bytes(segment, "missile", 0x7e09c8)
            updateAmmoFrom2Bytes(segment, "supers", 0x7e09cc)
            updateAmmoFrom2Bytes(segment, "pb", 0x7e09d0)
            updateAmmoFrom2Bytes(segment, "reserve", 0x7e09d4)
            return true
        else
            return false
        end
    end
end

function updateAmmoFromMemorySegmentInactiveSM(segment)
    InvalidateReadCaches()
    local address = 0x703920
    if AutoTracker.SelectedConnectorType.Name ~= "SD2SNES" then
        address = address + 0x314000
    end
    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        if AUTOTRACKER_IS_IN_LTTP and AUTOTRACKER_IS_IN_GAME then
            updateAmmoFrom2Bytes(segment, "etank", address + 0x04)
            updateAmmoFrom2Bytes(segment, "missile", address + 0x08)
            updateAmmoFrom2Bytes(segment, "supers", address + 0x0c)
            updateAmmoFrom2Bytes(segment, "pb", address + 0x10)
            updateAmmoFrom2Bytes(segment, "reserve", address + 0x14)
            return true
        else
            return false
        end
    end
end

function updateAgaFromMemorySegmentActiveLTTP(segment)
    updateAga1(segment)
    SAVED_AGA1 = saveAga1(segment)
end

function updateSMBosses(segment)
    if AUTOTRACKER_IS_IN_SM and AUTOTRACKER_IS_IN_GAME_SM then
        for i = 0x7ed828, 0x7ed82F, 1
        do
            print (i-0x7ed827)
            print (ReadU8(segment, i))
        end
        updateToggleItemFromByteAndFlag(segment, "kraid", 0x7ed829, 0x01)
        updateToggleItemFromByteAndFlag(segment, "ridley", 0x7ed82a, 0x01)
        updateToggleItemFromByteAndFlag(segment, "phantoon", 0x7ed82b, 0x01)
        updateToggleItemFromByteAndFlag(segment, "draygon", 0x7ed82c, 0x01)
        return true
    else
        return false
    end
end

sramWatchGame = nil
sramWatchLTTPinSM = nil
sramWatchSMinLTTP = nil
sramWatchLTTPDone = nil
sramWatchSMDone = nil
sramWatchSMAmmo = nil

function autotracker_started()
    --  Remove existing SRAM watches
    if sramMemoryWatch then
        ScriptHost:RemoveMemoryWatch(sramWatchGame)
        ScriptHost:RemoveMemoryWatch(sramWatchLTTPinSM)
        ScriptHost:RemoveMemoryWatch(sramWatchSMinLTTP)
        ScriptHost:RemoveMemoryWatch(sramWatchSMAmmo)
        ScriptHost:RemoveMemoryWatch(sramWatchLTTPDone)
        ScriptHost:RemoveMemoryWatch(sramWatchSMDone)
        sramWatchGame = nil
        sramWatchLTTPinSM = nil
        sramWatchSMinLTTP = nil
        sramWatchLTTPDone = nil
        sramWatchSMDone = nil
        sramWatchSMAmmo = nil
    end

    -- Invoked when the auto-tracker is activated/connected
    if AutoTracker.SelectedConnectorType.Name == "SD2SNES" then
        --  Initialize SD2SNES SRAM watches
        sramWatchGame = ScriptHost:AddMemoryWatch("Which Game Is It Anyways", 0x7033fe, 0x02, updateGame, 250)
        sramWatchLTTPinSM = ScriptHost:AddMemoryWatch("LTTP Data In SM", 0x703B40, 0x50, updateItemsFromMemorySegmentInactiveLTTP)
        sramWatchSMinLTTP = ScriptHost:AddMemoryWatch("SM Data In LTTP", 0x703900, 0x10, updateItemsFromMemorySegmentInactiveSM)
        sramWatchSMAmmo = ScriptHost:AddMemoryWatch("SM Ammo Data in LTTP", 0x703920, 0x16, updateAmmoFromMemorySegmentInactiveSM)
        sramWatchLTTPDone = ScriptHost:AddMemoryWatch("LTTP DONE", 0x703506, 0x01, updateLTTPcompletion)
        sramWatchSMDone = ScriptHost:AddMemoryWatch("SM DONE", 0x703402, 0x02, updateSMcompletion)
    else
        --  Initialize Lua SRAM watches
        sramWatchGame = ScriptHost:AddMemoryWatch("Which Game Is It Anyways", 0xa173fe, 0x02, updateGame, 250)
        sramWatchLTTPinSM = ScriptHost:AddMemoryWatch("LTTP Data In SM", 0xa17b40, 0x50, updateItemsFromMemorySegmentInactiveLTTP)
        sramWatchSMinLTTP = ScriptHost:AddMemoryWatch("SM Data In LTTP", 0xa17900, 0x10, updateItemsFromMemorySegmentInactiveSM)
        sramWatchSMAmmo = ScriptHost:AddMemoryWatch("SM Ammo Data in LTTP", 0xa17920, 0x16, updateAmmoFromMemorySegmentInactiveSM)
        sramWatchLTTPDone = ScriptHost:AddMemoryWatch("LTTP DONE", 0xa17506, 0x01, updateLTTPcompletion)
        sramWatchSMDone = ScriptHost:AddMemoryWatch("SM DONE", 0xa17402, 0x02, updateSMcompletion)
    end
end

ScriptHost:AddMemoryWatch("LTTP In-Game status", 0x7e0010, 0x01, updateInGameStatusFromMemorySegment, 250)
ScriptHost:AddMemoryWatch("SM In-Game status", 0x7e0998, 0x01, updateInGameStatusSM, 250)
ScriptHost:AddMemoryWatch("LTTP Item Data", 0x7ef340, 0x50, updateItemsFromMemorySegmentActiveLTTP)
ScriptHost:AddMemoryWatch("LTTP Aga1", 0x7ef3c5, 0x01, updateAgaFromMemorySegmentActiveLTTP)
ScriptHost:AddMemoryWatch("SM Item Data", 0x7e09A0, 0x10, updateItemsFromMemorySegmentActiveSM)
ScriptHost:AddMemoryWatch("SM Ammo Data", 0x7e09C2, 0x16, updateAmmoFromMemorySegmentActiveSM)
ScriptHost:AddMemoryWatch("LTTP Room Data", 0x7ef000, 0x250, updateRoomsFromMemorySegment)
ScriptHost:AddMemoryWatch("SM Boss Data", 0x7ed828, 0x08, updateSMBosses)