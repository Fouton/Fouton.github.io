-- Configuration --------------------------------------
AUTOTRACKER_ENABLE_DEBUG_LOGGING = false
-------------------------------------------------------

print("")
print("Active Auto-Tracker Configuration")
print("---------------------------------------------------------------------")
print("Enable Item Tracking:        ", AUTOTRACKER_ENABLE_ITEM_TRACKING)
print("Enable Location Tracking:    ", AUTOTRACKER_ENABLE_LOCATION_TRACKING)
if AUTOTRACKER_ENABLE_DEBUG_LOGGING then
    print("Enable Debug Logging:        ", "true")
end
print("---------------------------------------------------------------------")
print("")

AUTOTRACKER_IS_IN_GAME = false
AUTOTRACKER_IS_IN_SM = true
AUTOTRACKER_IS_IN_GAME_SM = false
AUTOTRACKER_IS_IN_LTTP = false

U8_READ_CACHE = 0
U8_READ_CACHE_ADDRESS = 0

U16_READ_CACHE = 0
U16_READ_CACHE_ADDRESS = 0

function InvalidateReadCaches()
    U8_READ_CACHE_ADDRESS = 0
    U16_READ_CACHE_ADDRESS = 0
end

function ReadU8(segment, address)
    if U8_READ_CACHE_ADDRESS ~= address then
        U8_READ_CACHE = segment:ReadUInt8(address)
        U8_READ_CACHE_ADDRESS = address        
    end

    return U8_READ_CACHE
end

function ReadU16(segment, address)
    if U16_READ_CACHE_ADDRESS ~= address then
        U16_READ_CACHE = segment:ReadUInt16(address)
        U16_READ_CACHE_ADDRESS = address        
    end

    return U16_READ_CACHE
end

function updateConsumableItemFromTwoByteSum(segment, code, address, address2)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        local value2 = ReadU8(segment, address2)
        item.CurrentStage = value + value2
    end
end

function DetermineGame(phrase)
    InvalidateReadCaches()
    local address = 0x7033fe
    if AutoTracker.SelectedConnectorType.Name ~= 'SD2SNES' then
        address = address + 0x314000
    end
    local value = AutoTracker:ReadU8(address, 0xFF)
    if value == 0x00 then
        AUTOTRACKER_IS_IN_LTTP = true
        AUTOTRACKER_IS_IN_SM = false
        value = AutoTracker:ReadU8(0x7e0010, 0)
        AUTOTRACKER_IS_IN_GAME = (value > 0x05 and value ~= 0x17)
        AUTOTRACKER_IS_IN_GAME_SM = false
        print("LTTP: " .. value .. ", called by: " .. phrase)
    elseif value == 0xFF then
        AUTOTRACKER_IS_IN_LTTP = false
        AUTOTRACKER_IS_IN_SM = true
        value = AutoTracker:ReadU8(0x7e0998, 0)
        AUTOTRACKER_IS_IN_GAME_SM = (value == 0x08)
        AUTOTRACKER_IS_IN_GAME = false
        print("SM: " .. value .. ", called by: " .. phrase)
    else
        AUTOTRACKER_IS_IN_SM = false
        AUTOTRACKER_IS_IN_LTTP = false
        AUTOTRACKER_IS_IN_GAME = false
        AUTOTRACKER_IS_IN_GAME_SM = false
        print("Game Error: " .. value .. ", called by: " .. phrase)
    end
end

function updateToggleFromRoomSlot(segment, code, slot)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local roomData = ReadU16(segment, 0x7ef000 + (slot[1] * 2))
        
        if AUTOTRACKER_ENABLE_DEBUG_LOGGING then
            print(roomData)
        end

        item.Active = (roomData & (1 << slot[2])) ~= 0
    end
end

function updateProgressiveItemFromByte(segment, code, address, offset)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        item.CurrentStage = value + (offset or 0)
    end
end

function updateConsumableItemFromByte(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        item.CurrentStage = value
    end
end

function updateAga1(segment)
    local item = Tracker:FindObjectForCode("aga1")
    local value = ReadU8(segment, 0x7ef3c5)
    if item then
        if value >= 3 then
            item.Active = true
        else
            item.Active = false
        end
    end
end

function updateBottles(segment)
    local item = Tracker:FindObjectForCode("bottle")    
    local count = 0
    for i = 0, 3, 1 do
        if ReadU8(segment, 0x7ef35c + i) > 0 then
            count = count + 1
        end
    end
    item.CurrentStage = count
end

function updateInactiveBottles(segment)
    local address= 0x703b5c
    if AutoTracker.SelectedConnectorType.Name ~= 'SD2SNES' then
        address = address + 0x314000
    end
    local item = Tracker:FindObjectForCode("bottle")    
    local count = 0
    for i = 0, 3, 1 do
        if ReadU8(segment, address + i) > 0 then
            count = count + 1
        end
    end
    item.CurrentStage = count
end

function updateToggleItemFromByte(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if value == 1 then
            item.Active = true
        elseif value == 0 then
            item.Active = false
        end
    end
end

function updateBow(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if value > 0 then
            item.Active = true
        elseif value == 0 then
            item.Active = false
        end
    end
end

function updateMirror(segment, address)
    local item = Tracker:FindObjectForCode("mirror")
    if item then
        local value = ReadU8(segment, address)
        if value == 1 or value == 2 then
            item.Active = true
        elseif value == 0 then
            item.Active = false
        end
    end
end

function updateAmmoFrom2Bytes(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    local value = ReadU8(segment, address+1)*256 + ReadU8(segment, address)
    if item then
        if code == "etank" then
            if value > 1499 then
                item.CurrentStage = 14
            else
                item.CurrentStage = value/100
            end
        elseif code == "reserve" then
            if value > 400 then
                item.CurrentStage = 4
            else
                item.CurrentStage = value/100
            end
        else
            if value > 200 then
                if code == "missile" then
                    item.CurrentStage = 39
                elseif code == "supers" then
                    item.CurrentStage = 19
                elseif code == "pb" then
                    item.CurrentStage = 19
                end
            elseif value > 95 and (code == "supers" or code == "pb") then
                item.CurrentStage = 19
            elseif value > 195 then
                item.CurrentStage = 39
            else
                item.CurrentStage = value/5
            end
        end
    end
end

function updateToggleItemFromByteAndFlag(segment, code, address, flag)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)

        local flagTest = value & flag

        if flagTest ~= 0 then
            item.Active = true
        else
            item.Active = false
        end
        if code == "ridley" or code == "draygon" or code == "kraid" or code == "phantoon" then
            print(item.Name, " ",flagTest)
        end
    end
end

function updateFlute(segment)
    local item = Tracker:FindObjectForCode("flute")
    local value = ReadU8(segment, 0x7ef38c)

    local fakeFlute = value & 0x02
    local realFlute = value & 0x01

    if realFlute ~= 0 then
        item.Active = true
    elseif fakeFlute ~= 0 then
        item.Active = true
    else
        item.Active = false
    end
end

function updateInactiveFlute(segment)
    local address = 0x703b8c
    if AutoTracker.SelectedConnectorType.Name ~= 'SD2SNES' then
        address = address + 0x314000
    end
    local item = Tracker:FindObjectForCode("flute")
    local value = ReadU8(segment, address)

    local fakeFlute = value & 0x02
    local realFlute = value & 0x01

    if realFlute ~= 0 then
        item.Active = true
    elseif fakeFlute ~= 0 then
        item.Active = true
    else
        item.Active = false
    end
end

function updateItemsFromMemorySegmentActiveLTTP(segment)

    InvalidateReadCaches()    

    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        DetermineGame("Active LTTP")
        if AUTOTRACKER_IS_IN_LTTP and AUTOTRACKER_IS_IN_GAME then

            updateProgressiveItemFromByte(segment, "sword",  0x7ef359)
            updateProgressiveItemFromByte(segment, "gloves", 0x7ef354)

            updateBow(segment, "bow", 0x7ef340)
            updateToggleItemFromByte(segment, "hookshot",  0x7ef342)
            updateToggleItemFromByte(segment, "firerod",   0x7ef345)
            updateToggleItemFromByte(segment, "icerod",    0x7ef346)
            updateToggleItemFromByte(segment, "bombos",    0x7ef347)
            updateToggleItemFromByte(segment, "ether",     0x7ef348)
            updateToggleItemFromByte(segment, "quake",     0x7ef349)
            updateToggleItemFromByte(segment, "lamp",      0x7ef34a)
            updateToggleItemFromByte(segment, "hammer",    0x7ef34b)
            updateToggleItemFromByte(segment, "book",      0x7ef34e)
            updateToggleItemFromByte(segment, "somaria",   0x7ef350)
            updateToggleItemFromByte(segment, "byrna",     0x7ef351)
            updateToggleItemFromByte(segment, "cape",      0x7ef352)
            updateMirror(segment, 0x7ef353)
            updateToggleItemFromByte(segment, "boots",     0x7ef355)
            updateToggleItemFromByte(segment, "flippers",  0x7ef356)
            updateToggleItemFromByte(segment, "pearl",     0x7ef357)
            updateToggleItemFromByte(segment, "halfmagic", 0x7ef37b)

            updateToggleItemFromByteAndFlag(segment, "blueboom", 0x7ef38c, 0x80)
            updateToggleItemFromByteAndFlag(segment, "redboom",  0x7ef38c, 0x40)
            updateToggleItemFromByteAndFlag(segment, "powder", 0x7ef38c, 0x10)
            updateToggleItemFromByteAndFlag(segment, "silvers", 0x7ef38e, 0x40)

            updateToggleItemFromByteAndFlag(segment, "mushroom", 0x7ef38c, 0x20)
            updateToggleItemFromByteAndFlag(segment, "shovel", 0x7ef38c, 0x04)

            updateBottles(segment)
            updateFlute(segment)

            updateToggleItemFromByteAndFlag(segment, "gtbk",  0x7ef366, 0x04)
            updateToggleItemFromByteAndFlag(segment, "trbk",  0x7ef366, 0x08)
            updateToggleItemFromByteAndFlag(segment, "ttbk",  0x7ef366, 0x10)
            updateToggleItemFromByteAndFlag(segment, "tohbk", 0x7ef366, 0x20)
            updateToggleItemFromByteAndFlag(segment, "ipbk",  0x7ef366, 0x40)    
            updateToggleItemFromByteAndFlag(segment, "swbk",  0x7ef366, 0x80)
            updateToggleItemFromByteAndFlag(segment, "mmbk",  0x7ef367, 0x01)
            updateToggleItemFromByteAndFlag(segment, "podbk", 0x7ef367, 0x02)
            updateToggleItemFromByteAndFlag(segment, "spbk",  0x7ef367, 0x04)
            updateToggleItemFromByteAndFlag(segment, "dpbk",  0x7ef367, 0x10)
            updateToggleItemFromByteAndFlag(segment, "epbk",  0x7ef367, 0x20)
        end
    end
end

function updateChestKeysFromActiveLTTP(segment)

    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        if not AUTOTRACKER_IS_IN_LTTP or not AUTOTRACKER_IS_IN_GAME then
            return false
        end

        DetermineGame("Active LTTP Keys")
        InvalidateReadCaches()

        if AUTOTRACKER_IS_IN_GAME and AUTOTRACKER_IS_IN_LTTP then
            updateConsumableItemFromTwoByteSum(segment, "hcsk", 0x7ef4e0, 0x7ef4e1)
            -- updateConsumableItemFromByte(segment, "epsk",  0x7ef4e2)
            updateConsumableItemFromByte(segment, "dpsk",  0x7ef4e3)
            updateConsumableItemFromByte(segment, "atsk",  0x7ef4e4)
            updateConsumableItemFromByte(segment, "spsk",  0x7ef4e5)
            updateConsumableItemFromByte(segment, "podsk", 0x7ef4e6)
            updateConsumableItemFromByte(segment, "mmsk",  0x7ef4e7)
            updateConsumableItemFromByte(segment, "swsk",  0x7ef4e8)
            updateConsumableItemFromByte(segment, "ipsk",  0x7ef4e9)
            updateConsumableItemFromByte(segment, "tohsk", 0x7ef4ea)
            updateConsumableItemFromByte(segment, "ttsk",  0x7ef4eb)
            updateConsumableItemFromByte(segment, "trsk",  0x7ef4ec)
            updateConsumableItemFromByte(segment, "gtsk",  0x7ef4ed)
        
        end
    end
end

function updateRoomsFromMemorySegment(segment)
    DetermineGame("boss completion")
    if AUTOTRACKER_IS_IN_LTTP and AUTOTRACKER_IS_IN_GAME then
        updateToggleFromRoomSlot(segment, "ep", { 200, 11 })
        updateToggleFromRoomSlot(segment, "dp", { 51, 11 })
        updateToggleFromRoomSlot(segment, "toh", { 7, 11 })
        updateToggleFromRoomSlot(segment, "pod", { 90, 11 })
        updateToggleFromRoomSlot(segment, "sp", { 6, 11 })
        updateToggleFromRoomSlot(segment, "sw", { 41, 11 })
        updateToggleFromRoomSlot(segment, "tt", { 172, 11 })
        updateToggleFromRoomSlot(segment, "ip", { 222, 11 })
        updateToggleFromRoomSlot(segment, "mm", { 144, 11 })
        updateToggleFromRoomSlot(segment, "tr", { 164, 11 })
    end
end

function updateLTTPcompletion(segment)
    local address = 0x703506
    if AutoTracker.SelectedConnectorType.Name ~= "SD2SNES" then
        address = address + 0x314000
    end
    DetermineGame("Ganon Check")
    if AUTOTRACKER_IS_IN_LTTP then
        local item = Tracker:FindObjectForCode("ganon")
        if (ReadU8(segment, address) == 0x01) then
            item.Active = true
        end
    end
end

function updateSMcompletion(segment)
    local address = 0x703403
    if AutoTracker.SelectedConnectorType.Name ~= "SD2SNES" then
        address = address + 0x314000
    end
    DetermineGame("Mother Brain Check")
    if AUTOTRACKER_IS_IN_SM then
        local item = Tracker:FindObjectForCode("brain")
        if (ReadU8(segment, address) == 0x01) then
            item.Active = true
        end
    end
end

function updateItemsFromMemorySegmentInactiveLTTP(segment)
    local address = 0x703b00
    if AutoTracker.SelectedConnectorType.Name ~= "SD2SNES" then
        address = address + 0x314000
    end
    
    InvalidateReadCaches()
    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        DetermineGame("Inactive LTTP")
        if AUTOTRACKER_IS_IN_SM then

            updateProgressiveItemFromByte(segment, "sword",  address + 0x59)
            updateProgressiveItemFromByte(segment, "gloves", address + 0x54)

            updateBow(segment, "bow", address + 0x40)
            updateToggleItemFromByte(segment, "hookshot",  address + 0x42)
            updateToggleItemFromByte(segment, "firerod",   address + 0x45)
            updateToggleItemFromByte(segment, "icerod",    address + 0x46)
            updateToggleItemFromByte(segment, "bombos",    address + 0x47)
            updateToggleItemFromByte(segment, "ether",     address + 0x48)
            updateToggleItemFromByte(segment, "quake",     address + 0x49)
            updateToggleItemFromByte(segment, "lamp",      address + 0x4a)
            updateToggleItemFromByte(segment, "hammer",    address + 0x4b)
            updateToggleItemFromByte(segment, "book",      address + 0x4e)
            updateToggleItemFromByte(segment, "somaria",   address + 0x50)
            updateToggleItemFromByte(segment, "byrna",     address + 0x51)
            updateToggleItemFromByte(segment, "cape",      address + 0x52)
            updateMirror(segment, address + 0x53)
            updateToggleItemFromByte(segment, "boots",     address + 0x55)
            updateToggleItemFromByte(segment, "flippers",  address + 0x56)
            updateToggleItemFromByte(segment, "pearl",     address + 0x57)
            updateToggleItemFromByte(segment, "halfmagic", address + 0x7b)

            updateToggleItemFromByteAndFlag(segment, "blueboom", address + 0x8c, 0x80)
            updateToggleItemFromByteAndFlag(segment, "redboom",  address + 0x8c, 0x40)
            updateToggleItemFromByteAndFlag(segment, "powder", address + 0x8c, 0x10)
            updateToggleItemFromByteAndFlag(segment, "silvers", address + 0x8e, 0x40)

            updateToggleItemFromByteAndFlag(segment, "mushroom", address + 0x8c, 0x20)
            updateToggleItemFromByteAndFlag(segment, "shovel", address + 0x8c, 0x04)

            updateInactiveBottles(segment)
            updateInactiveFlute(segment)
            
            updateToggleItemFromByteAndFlag(segment, "gtbk",  address + 0x66, 0x04)
            updateToggleItemFromByteAndFlag(segment, "trbk",  address + 0x66, 0x08)
            updateToggleItemFromByteAndFlag(segment, "ttbk",  address + 0x66, 0x10)
            updateToggleItemFromByteAndFlag(segment, "tohbk", address + 0x66, 0x20)
            updateToggleItemFromByteAndFlag(segment, "ipbk",  address + 0x66, 0x40)    
            updateToggleItemFromByteAndFlag(segment, "swbk",  address + 0x66, 0x80)
            updateToggleItemFromByteAndFlag(segment, "mmbk",  address + 0x67, 0x01)
            updateToggleItemFromByteAndFlag(segment, "podbk", address + 0x67, 0x02)
            updateToggleItemFromByteAndFlag(segment, "spbk",  address + 0x67, 0x04)
            updateToggleItemFromByteAndFlag(segment, "dpbk",  address + 0x67, 0x10)
            updateToggleItemFromByteAndFlag(segment, "epbk",  address + 0x67, 0x20)
        end
    end
end

function updateChestKeysFromInactiveLTTP(segment)
    local address = 0x703f50
    if AutoTracker.SelectedConnectorType.Name ~= "SD2SNES" then
        address = address + 0x314000
    end
    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        DetermineGame("Inactive LTTP Keys")
        if not AUTOTRACKER_IS_IN_SM then
            return false
        end
        InvalidateReadCaches()

        if AUTOTRACKER_IS_IN_SM then
            updateConsumableItemFromTwoByteSum(segment, "hcsk", address, address + 0x01)
            -- updateConsumableItemFromByte(segment, "epsk",  address + 0x02)
            updateConsumableItemFromByte(segment, "dpsk",  address + 0x03)
            updateConsumableItemFromByte(segment, "atsk",  address + 0x04)
            updateConsumableItemFromByte(segment, "spsk",  address + 0x05)
            updateConsumableItemFromByte(segment, "podsk", address + 0x06)
            updateConsumableItemFromByte(segment, "mmsk",  address + 0x07)
            updateConsumableItemFromByte(segment, "swsk",  address + 0x08)
            updateConsumableItemFromByte(segment, "ipsk",  address + 0x09)
            updateConsumableItemFromByte(segment, "tohsk", address + 0x0A)
            updateConsumableItemFromByte(segment, "ttsk",  address + 0x0B)
            updateConsumableItemFromByte(segment, "trsk",  address + 0x0C)
            updateConsumableItemFromByte(segment, "gtsk",  address + 0x0D)
        
        end
    end
end

function updateItemsFromMemorySegmentActiveSM(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        DetermineGame("Active SM")
        if AUTOTRACKER_IS_IN_SM and AUTOTRACKER_IS_IN_GAME_SM then

            updateToggleItemFromByteAndFlag(segment, "varia", 0x7E09A4, 0x01)
            updateToggleItemFromByteAndFlag(segment, "springball", 0x7E09A4, 0x02)
            updateToggleItemFromByteAndFlag(segment, "morph", 0x7E09A4, 0x04)
            updateToggleItemFromByteAndFlag(segment, "screw", 0x7E09A4, 0x08)
            updateToggleItemFromByteAndFlag(segment, "gravity", 0x7E09A4, 0x20)

            updateToggleItemFromByteAndFlag(segment, "hijump", 0x7E09A5, 0x01)
            updateToggleItemFromByteAndFlag(segment, "spacejump", 0x7E09A5, 0x02)
            updateToggleItemFromByteAndFlag(segment, "bomb", 0x7E09A5, 0x10)
            updateToggleItemFromByteAndFlag(segment, "speedbooster", 0x7E09A5, 0x20)
            updateToggleItemFromByteAndFlag(segment, "grapple", 0x7E09A5, 0x40)
            updateToggleItemFromByteAndFlag(segment, "xray", 0x7E09A5, 0x80)

            updateToggleItemFromByteAndFlag(segment, "wave", 0x7E09A8, 0x01)
            updateToggleItemFromByteAndFlag(segment, "ibeam", 0x7E09A8, 0x02)
            updateToggleItemFromByteAndFlag(segment, "spazer", 0x7E09A8, 0x04)
            updateToggleItemFromByteAndFlag(segment, "plasma", 0x7E09A8, 0x08)
            updateToggleItemFromByteAndFlag(segment, "charge", 0x7E09A9, 0x10)
        end
    end
end

function updateItemsFromMemorySegmentInactiveSM(segment)
    InvalidateReadCaches()
    local address = 0x703900
    if AutoTracker.SelectedConnectorType.Name ~= "SD2SNES" then
        address = address + 0x314000
    end
    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        DetermineGame("Inactive SM")
        if AUTOTRACKER_IS_IN_LTTP and AUTOTRACKER_IS_IN_GAME then
            updateToggleItemFromByteAndFlag(segment, "varia", address + 0x02, 0x01)
            updateToggleItemFromByteAndFlag(segment, "springball", address + 0x02, 0x02)
            updateToggleItemFromByteAndFlag(segment, "morph", address + 0x02, 0x04)
            updateToggleItemFromByteAndFlag(segment, "screw", address + 0x02, 0x08)
            updateToggleItemFromByteAndFlag(segment, "gravity", address + 0x02, 0x20)

            updateToggleItemFromByteAndFlag(segment, "hijump", address + 0x03, 0x01)
            updateToggleItemFromByteAndFlag(segment, "spacejump", address + 0x03, 0x02)
            updateToggleItemFromByteAndFlag(segment, "bomb", address + 0x03, 0x10)
            updateToggleItemFromByteAndFlag(segment, "speedbooster", address + 0x03, 0x20)
            updateToggleItemFromByteAndFlag(segment, "grapple", address + 0x03, 0x40)
            updateToggleItemFromByteAndFlag(segment, "xray", address + 0x03, 0x80)

            updateToggleItemFromByteAndFlag(segment, "wave", address + 0x06, 0x01)
            updateToggleItemFromByteAndFlag(segment, "ibeam", address + 0x06, 0x02)
            updateToggleItemFromByteAndFlag(segment, "spazer", address + 0x06, 0x04)
            updateToggleItemFromByteAndFlag(segment, "plasma", address + 0x06, 0x08)
            updateToggleItemFromByteAndFlag(segment, "charge", address + 0x07, 0x10)
        end
    end
end

function updateKeysFromMemorySegmentInactiveSM(segment)
    InvalidateReadCaches()
    local address = 0x703970
    if AutoTracker.SelectedConnectorType.Name ~= "SD2SNES" then
        address = address + 0x314000
    end
    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        DetermineGame("Inactive SM Keys")
        if AUTOTRACKER_IS_IN_LTTP and AUTOTRACKER_IS_IN_GAME then
            local keyItem = Tracker:FindObjectForCode("cratdoor1")
            if keyItem then
                updateToggleItemFromByteAndFlag(segment, "cratdoor1", address, 0x01)
                updateToggleItemFromByteAndFlag(segment, "cratdoor2", address, 0x02)
                updateToggleItemFromByteAndFlag(segment, "cratbossdoor", address, 0x04)
                updateToggleItemFromByteAndFlag(segment, "brindoor1", address, 0x08)
                updateToggleItemFromByteAndFlag(segment, "brindoor2", address, 0x10)
                updateToggleItemFromByteAndFlag(segment, "brinbossdoor", address, 0x20)
                updateToggleItemFromByteAndFlag(segment, "undoor1", address, 0x40)
                updateToggleItemFromByteAndFlag(segment, "undoor2", address, 0x80)
                updateToggleItemFromByteAndFlag(segment, "unbossdoor", address + 0x01, 0x01)
                updateToggleItemFromByteAndFlag(segment, "maridoor1", address + 0x01, 0x02)
                updateToggleItemFromByteAndFlag(segment, "maridoor2", address + 0x01, 0x04)
                updateToggleItemFromByteAndFlag(segment, "maribossdoor", address + 0x01, 0x08)
                updateToggleItemFromByteAndFlag(segment, "wsdoor1", address + 0x01, 0x10)
                updateToggleItemFromByteAndFlag(segment, "wsbossdoor", address + 0x01, 0x20)
                updateToggleItemFromByteAndFlag(segment, "lndoor1", address + 0x01, 0x40)
                updateToggleItemFromByteAndFlag(segment, "lnbossdoor", address + 0x01, 0x80)
            end
        end
    end
end

function updateAmmoFromMemorySegmentActiveSM(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        DetermineGame("Ammo Check")
        if AUTOTRACKER_IS_IN_SM and AUTOTRACKER_IS_IN_GAME_SM then
            updateAmmoFrom2Bytes(segment, "etank", 0x7e09c4)
            updateAmmoFrom2Bytes(segment, "missile", 0x7e09c8)
            updateAmmoFrom2Bytes(segment, "supers", 0x7e09cc)
            updateAmmoFrom2Bytes(segment, "pb", 0x7e09d0)
            updateAmmoFrom2Bytes(segment, "reserve", 0x7e09d4)
        end
    end
end

function updateAmmoFromMemorySegmentInactiveSM(segment)
    InvalidateReadCaches()
    local address = 0x703920
    if AutoTracker.SelectedConnectorType.Name ~= "SD2SNES" then
        address = address + 0x314000
    end
    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        DetermineGame("Inactive Ammo Check")
        if AUTOTRACKER_IS_IN_LTTP and AUTOTRACKER_IS_IN_GAME then
            updateAmmoFrom2Bytes(segment, "etank", address + 0x04)
            updateAmmoFrom2Bytes(segment, "missile", address + 0x08)
            updateAmmoFrom2Bytes(segment, "supers", address + 0x0c)
            updateAmmoFrom2Bytes(segment, "pb", address + 0x10)
            updateAmmoFrom2Bytes(segment, "reserve", address + 0x14)
        end
    end
end

function updateAgaFromMemorySegmentActiveLTTP(segment)
    DetermineGame("Agahnim Check")
    if AUTOTRACKER_IS_IN_LTTP and AUTOTRACKER_IS_IN_GAME then
        updateAga1(segment)
    end
end

function updateSMBossesandKeys(segment)
    DetermineGame("SM Bosses")
    if AUTOTRACKER_IS_IN_SM and AUTOTRACKER_IS_IN_GAME_SM then
        for i = 0x7ed828, 0x7ed82F, 1
        do
            print ("" .. i-0x7ed827 .. " " .. ReadU8(segment, i))
        end

        if string.find(Tracker.ActiveVariantUID, "classic") then
            updateToggleItemFromByteAndFlag(segment, "goldkraid", 0x7ed829, 0x01)
            updateToggleItemFromByteAndFlag(segment, "goldridley", 0x7ed82a, 0x01)
            updateToggleItemFromByteAndFlag(segment, "goldphantoon", 0x7ed82b, 0x01)
            updateToggleItemFromByteAndFlag(segment, "golddraygon", 0x7ed82c, 0x01)
        else
            updateToggleItemFromByteAndFlag(segment, "kraid", 0x7ed829, 0x01)
            updateToggleItemFromByteAndFlag(segment, "ridley", 0x7ed82a, 0x01)
            updateToggleItemFromByteAndFlag(segment, "phantoon", 0x7ed82b, 0x01)
            updateToggleItemFromByteAndFlag(segment, "draygon", 0x7ed82c, 0x01)
        end

        local keyItem = Tracker:FindObjectForCode("cratdoor1")
        if keyItem then
            updateToggleItemFromByteAndFlag(segment, "cratdoor1", 0x7ed830, 0x01)
            updateToggleItemFromByteAndFlag(segment, "cratdoor2", 0x7ed830, 0x02)
            updateToggleItemFromByteAndFlag(segment, "cratbossdoor", 0x7ed830, 0x04)
            updateToggleItemFromByteAndFlag(segment, "brindoor1", 0x7ed830, 0x08)
            updateToggleItemFromByteAndFlag(segment, "brindoor2", 0x7ed830, 0x10)
            updateToggleItemFromByteAndFlag(segment, "brinbossdoor", 0x7ed830, 0x20)
            updateToggleItemFromByteAndFlag(segment, "undoor1", 0x7ed830, 0x40)
            updateToggleItemFromByteAndFlag(segment, "undoor2", 0x7ed830, 0x80)
            updateToggleItemFromByteAndFlag(segment, "unbossdoor", 0x7ed831, 0x01)
            updateToggleItemFromByteAndFlag(segment, "maridoor1", 0x7ed831, 0x02)
            updateToggleItemFromByteAndFlag(segment, "maridoor2", 0x7ed831, 0x04)
            updateToggleItemFromByteAndFlag(segment, "maribossdoor", 0x7ed831, 0x08)
            updateToggleItemFromByteAndFlag(segment, "wsdoor1", 0x7ed831, 0x10)
            updateToggleItemFromByteAndFlag(segment, "wsbossdoor", 0x7ed831, 0x20)
            updateToggleItemFromByteAndFlag(segment, "lndoor1", 0x7ed831, 0x40)
            updateToggleItemFromByteAndFlag(segment, "lnbossdoor", 0x7ed831, 0x80)
        end
    end
end

sramWatchLTTPinSM = nil
sramWatchSMinLTTP = nil
sramWatchSMKeysinLTTP = nil
sramWatchLTTPDone = nil
sramWatchSMDone = nil
sramWatchSMAmmo = nil
sramWatchLTTPKeysinSM = nil

function autotracker_started()
    --  Remove existing SRAM watches
    if sramWatchLTTPinSM then
        ScriptHost:RemoveMemoryWatch(sramWatchLTTPinSM)
        sramWatchLTTPinSM = nil
    end
    if sramWatchSMinLTTP then
        ScriptHost:RemoveMemoryWatch(sramWatchSMinLTTP)
        sramWatchSMinLTTP = nil
    end
    if sramWatchSMKeysinLTTP then
        ScriptHost:RemoveMemoryWatch(sramWatchSMKeysinLTTP)
        sramWatchSMKeysinLTTP = nil
    end
    if sramWatchSMAmmo then
        ScriptHost:RemoveMemoryWatch(sramWatchSMAmmo)
        sramWatchSMAmmo = nil
    end
    if sramWatchLTTPDone then
        ScriptHost:RemoveMemoryWatch(sramWatchLTTPDone)
        sramWatchLTTPDone = nil
    end
    if sramWatchSMDone then
        ScriptHost:RemoveMemoryWatch(sramWatchSMDone)
        sramWatchSMDone = nil
    end
    if sramWatchLTTPKeysinSM then
        ScriptHost:RemoveMemoryWatch(sramWatchLTTPKeysinSM)
        sramWatchLTTPKeysinSM = nil
    end

    -- Invoked when the auto-tracker is activated/connected
    if AutoTracker.SelectedConnectorType.Name == "SD2SNES" then
        --  Initialize SD2SNES SRAM watches
        sramWatchLTTPinSM = ScriptHost:AddMemoryWatch("LTTP Data In SM", 0x703B40, 0x50, updateItemsFromMemorySegmentInactiveLTTP)
        sramWatchSMinLTTP = ScriptHost:AddMemoryWatch("SM Data In LTTP", 0x703900, 0x10, updateItemsFromMemorySegmentInactiveSM)
        sramWatchSMKeysinLTTP = ScriptHost:AddMemoryWatch("SM Key Data In LTTP", 0x703970, 0x06, updateKeysFromMemorySegmentInactiveSM)
        --sramWatchSMAmmo = ScriptHost:AddMemoryWatch("SM Ammo Data in LTTP", 0x703920, 0x16, updateAmmoFromMemorySegmentInactiveSM)
        sramWatchLTTPDone = ScriptHost:AddMemoryWatch("LTTP DONE", 0x703506, 0x01, updateLTTPcompletion)
        sramWatchSMDone = ScriptHost:AddMemoryWatch("SM DONE", 0x703402, 0x02, updateSMcompletion)
        sramWatchLTTPKeysinSM = ScriptHost:AddMemoryWatch("LTTP Key Data In SM", 0x703f50, 0x10, updateChestKeysFromInactiveLTTP)
    else
        --  Initialize Lua SRAM watches
        sramWatchLTTPinSM = ScriptHost:AddMemoryWatch("LTTP Data In SM", 0xa17b40, 0x50, updateItemsFromMemorySegmentInactiveLTTP)
        sramWatchSMinLTTP = ScriptHost:AddMemoryWatch("SM Data In LTTP", 0xa17900, 0x10, updateItemsFromMemorySegmentInactiveSM)
        sramWatchSMKeysinLTTP = ScriptHost:AddMemoryWatch("SM Key Data In LTTP", 0xa17970, 0x06, updateKeysFromMemorySegmentInactiveSM)
        --sramWatchSMAmmo = ScriptHost:AddMemoryWatch("SM Ammo Data in LTTP", 0xa17920, 0x16, updateAmmoFromMemorySegmentInactiveSM)
        sramWatchLTTPDone = ScriptHost:AddMemoryWatch("LTTP DONE", 0xa17506, 0x01, updateLTTPcompletion)
        sramWatchSMDone = ScriptHost:AddMemoryWatch("SM DONE", 0xa17402, 0x02, updateSMcompletion)
        sramWatchLTTPKeysinSM = ScriptHost:AddMemoryWatch("LTTP Key Data In SM", 0xa17f50, 0x10, updateChestKeysFromInactiveLTTP)
    end
end

ScriptHost:AddMemoryWatch("LTTP Item Data", 0x7ef340, 0x50, updateItemsFromMemorySegmentActiveLTTP)
ScriptHost:AddMemoryWatch("LTTP Aga1", 0x7ef3c5, 0x01, updateAgaFromMemorySegmentActiveLTTP)
ScriptHost:AddMemoryWatch("SM Item Data", 0x7e09A4, 0x05, updateItemsFromMemorySegmentActiveSM)
--ScriptHost:AddMemoryWatch("SM Ammo Data", 0x7e09C2, 0x16, updateAmmoFromMemorySegmentActiveSM)
ScriptHost:AddMemoryWatch("LTTP Room Data", 0x7ef000, 0x250, updateRoomsFromMemorySegment)
ScriptHost:AddMemoryWatch("SM Boss and Key Data", 0x7ed828, 0x10, updateSMBossesandKeys)
ScriptHost:AddMemoryWatch("LTTP Chest Key Data", 0x7ef4e0, 0x10, updateChestKeysFromActiveLTTP)