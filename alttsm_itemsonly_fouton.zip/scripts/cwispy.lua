function tracker_on_accessibility_updated()
    local charge = Tracker:FindObjectForCode("charge")    
    local wave = Tracker:FindObjectForCode("wave")    
    local ibeam = Tracker:FindObjectForCode("ibeam")    
    local spazer = Tracker:FindObjectForCode("spazer")    
    local plasma = Tracker:FindObjectForCode("plasma")    

    local item = Tracker:FindObjectForCode("cwispy")

    if charge.Active and wave.Active and ibeam.Active and spazer.Active and plasma.Active then
        item.Active = true
    else
        item.Active = false
    end
end