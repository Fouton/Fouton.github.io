ScriptHost:LoadScript("scripts/class.lua")
ScriptHost:LoadScript("scripts/custom_item.lua")
ScriptHost:LoadScript("scripts/AnyKeyCount.lua")
ScriptHost:LoadScript("scripts/settings.lua")
local anykeycount = AnyKeyCount()
Tracker:AddItems("items/items.json")
Tracker:AddLayouts("layouts/tracker.json")
Tracker:AddLayouts("layouts/broadcast.json")
ScriptHost:LoadScript("scripts/cwispy.lua")

if _VERSION == "Lua 5.3" then
    --ScriptHost:LoadScript("scripts/autotracking.lua")
else    
    --print("Auto-tracker is unsupported by your tracker version")
end

function tracker_on_accessibility_updated()
    local charge = Tracker:FindObjectForCode("charge")    
    local wave = Tracker:FindObjectForCode("wave")    
    local ibeam = Tracker:FindObjectForCode("ibeam")    
    local spazer = Tracker:FindObjectForCode("spazer")    
    local plasma = Tracker:FindObjectForCode("plasma")    

    local item = Tracker:FindObjectForCode("cwispy")

    if charge.Active and wave.Active and ibeam.Active and spazer.Active and plasma.Active then
        item.Active = true
    else
        item.Active = false
    end

    local anykey = Tracker:FindObjectForCode("z1anyhead")

    if anykey.Active then
        anykeycount:SetAnyKey(true)
    else
        anykeycount:SetAnyKey(false)
    end
end