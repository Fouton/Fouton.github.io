local bowon = "images/z-bowshift.png"
local bowoff = "images/z-bowshiftoff.png"
local arrows = {
	"overlay|images/z-arrowsshiftoff.png",
	"overlay|images/z-arrowsshift.png",
	"overlay|images/z-silversshift.png"
}

GanonGoalItem = class(CustomItem)

function GanonGoalItem:init(name, code)
	self:createItem(name) 
	self.code = code
    self:setProperty("active", true)
	self.currentImage = bowoff
	self.ItemInstance.PotentialIcon = ImageReference:FromPackRelativePath(self.currentImage)
	self.currentOverlay = arrows[0]
	self.bow = false
	self.arrowcounter = 0
	self:updateIcon()
end

function GanonGoalItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function GanonGoalItem:providesCode(code)
    if code == self.code then
        return 1
    end
    return 0
end

function GanonGoalItem:onLeftClick()
	if self.bow then
		self.bow = false
	else
		self.bow = true
	end
	self:updateIcon()
end

function GanonGoalItem:onRightClick()
	if self.arrowcounter < 2 then
		self.arrowcounter = self.arrowcounter + 1
	else
		self.arrowcounter = 0
	end
	self:updateIcon()
end

function GanonGoalItem:updateIcon()
	if self.bow then
		self.currentImage = bowon
	else
		self.currentImage = bowoff
	end
	self.currentOverlay = arrows[self.arrowcounter+1]
	self.ItemInstance.Icon = ImageReference:FromPackRelativePath(self.currentImage, self.currentOverlay)
end

function GanonGoalItem:save()
	local saveData = {
		["z1bow"] = self.bow,
		["z1arrows"] = self.arrowcounter,
	}
	return saveData
end

function GanonGoalItem:load(data)
	if data ~= nil then
		self.bow = data["z1bow"]
		self.arrowcounter = data["z1arrows"]
		self:updateIcon()
	end
	return true
end