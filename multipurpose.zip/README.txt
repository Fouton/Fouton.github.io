How to add new icons to the tracker:

Get the image you want the icon to be, transparent is best.

Put the image in the images folder 

Make sure you remember the exact name of the image, for example there is Egg.png in the folder.

Go into scripts folder, edit the init.lua file in a text editor

you will see lines that have -- infront of them, they explain how to use the code there

essentially:
add a line that says table.insert(itemList,"imageName") in the file, before the for n = 1 line

if you were adding the Egg for example (which is already added so dont add it again)
you would put:
table.insert(itemList, "Egg")

and you'd be done. so do that, but with your image name, youre done.

Note: There can only be a total of 40 items in the pack at the moment. If you really really need to go beyond 40 you can either
1) copy the pack to make a second pack, for a second list of counters, and run 2 emotrackers at once
2) go into the layouts folder, tracker layout, and add the itemcodes for more than just 40 items in the same format that I have them entered in.