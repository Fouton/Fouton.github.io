ScriptHost:LoadScript("scripts/class.lua")
ScriptHost:LoadScript("scripts/custom_item.lua")
ScriptHost:LoadScript("scripts/RichCounter.lua")
ScriptHost:LoadScript("scripts/CounterIcon.lua")
ScriptHost:LoadScript("scripts/settings.lua")
itemList = {}
newCounters = {}
newIcons = {}

--Remove any of the following counters by just adding two hyphens infront of the line, just like this line has.
table.insert(itemList,"Normal")
table.insert(itemList,"Fire")
table.insert(itemList,"Water")
table.insert(itemList,"Electric")
table.insert(itemList,"Grass")
table.insert(itemList,"Ice")
table.insert(itemList,"Fighting")
table.insert(itemList,"Poison")
table.insert(itemList,"Ground")
table.insert(itemList,"Flying")
table.insert(itemList,"Psychic")
table.insert(itemList,"Bug")
table.insert(itemList,"Rock")
table.insert(itemList,"Ghost")
table.insert(itemList,"Dragon")
table.insert(itemList,"Dark")
table.insert(itemList,"Steel")
table.insert(itemList,"Fairy")
table.insert(itemList,"Egg")
--Add your own custom buttons here by following the same format of:
--add your image name into the "" (without .png) and create that as a new line, without -- infront of it
--NEVER add anything that has the same name as another, including the above codes. this will crash the tracker.

--table.insert(itemList,"imageName")


--Insert them above here
for n = 1, #itemList, 1 do
    newCounters = RichCounter(itemList[n],n)
    newIcons = CounterIcon(itemList[n],n)
end


Tracker:AddItems("items/items.json")
Tracker:AddLayouts("layouts/tracker.json")
Tracker:AddLayouts("layouts/broadcast.json")