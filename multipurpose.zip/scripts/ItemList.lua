local itemlist = nil

function ItemList:createItem(name, code, image)
	self:createItem(name) 
	self.code = code
    self:setProperty("active", true)
	self.currentImage = image
	self.count = 0
	self.ItemInstance.PotentialIcon = ImageReference:FromPackRelativePath(self.currentImage)
	self.currentOverlay = "null"
	self:updateIcon()
end

function RichCounter:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function RichCounter:providesCode(code)
    if code == self.code then
        return 1
    end
    return 0
end

function RichCounter:onLeftClick()
	if self.count > 998 then
		self.count = 0
	else
		self.count = self.count + 1
	end
	self:updateIcon()
end

function RichCounter:onRightClick()
	if self.count < 1 then
		self.count = 999
	else
		self.count = self.count - 1
	end
	self:updateIcon()
end

function RichCounter:updateIcon()
	if self.count < 100 then
		self.currentImage = lowDigitImage[self.count+1]
		self.currentOverlay = "null"
	else
		self.currentImage = largeDigitImage[(self.count%100)+1]
		self.currentOverlay = hundredImage[((self.count - (self.count%100))/100)]
	end
	self.ItemInstance.Icon = ImageReference:FromPackRelativePath(self.currentImage, self.currentOverlay)
end

function RichCounter:save()
	local saveData = {
		["count"] = self.count
	}
	return saveData
end

function RichCounter:load(data)
	if data ~= nil then
		self.count = data["count"]
		self:updateIcon()
	end
	return true
end