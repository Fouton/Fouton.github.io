CounterIcon = CustomItem:extend()

function CounterIcon:init(code, number)
	self:createItem("" .. code .. " Icon")
	self.richcode = "item" .. number .. "counter"
	self.code = "item" .. number .. "icon"
    self:setProperty("active", true)
	self.currentImage = "images/" .. code .. ".png"
	self.ItemInstance.PotentialIcon = ImageReference:FromPackRelativePath(self.currentImage)
	self.currentOverlay = "null"
	self:updateIcon()
end

function CounterIcon:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function CounterIcon:providesCode(code)
    if code == self.code then
        return 1
    end
    return 0
end

function CounterIcon:onLeftClick()
    local item = Tracker:FindObjectForCode(self.richcode)
    if item.ItemState.count > 998 then
        item.ItemState.count = 0
    else
        item.ItemState.count = item.ItemState.count + 1
    end
    item.ItemState:updateIcon()
end

function CounterIcon:onRightClick()
    local item = Tracker:FindObjectForCode(self.richcode)
	if item.ItemState.count < 1 then
		item.ItemState.count = 999
	else
		item.ItemState.count = item.ItemState.count - 1
	end
	item.ItemState:updateIcon()
end

function CounterIcon:updateIcon()
	self.ItemInstance.Icon = ImageReference:FromPackRelativePath(self.currentImage)
end