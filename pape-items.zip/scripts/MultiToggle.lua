MultiToggleItem = CustomItem:extend()

function MultiToggleItem:init(name, code, images)
	self:createItem(name) 
	self.code = code
    self:setProperty("active", true)
	self.images = images
	self.currentImage = "images/" .. images[1] .. ".png"
	self.stages = #images
	self.stage = 1
	self.toggle = {}
	for i = 1, #images, 1 do
		self.toggle[i] = false
	end
	self.ItemInstance.PotentialIcon = ImageReference:FromPackRelativePath(self.currentImage, "@disabled")
	self:updateIcon()
end

function MultiToggleItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function MultiToggleItem:providesCode(code)
    if code == self.code then
        return 1
    end
    return 0
end

function MultiToggleItem:onLeftClick()
	if self.toggle[self.stage] then
		self.toggle[self.stage] = false
	else
		self.toggle[self.stage] = true
	end
	self:updateIcon()
end

function MultiToggleItem:onRightClick()
	if self.stage < self.stages then
		self.stage = self.stage + 1
	else
		self.stage = 1
	end
	self:updateIcon()
end

function MultiToggleItem:updateIcon()
	local overlay = ""
	if self.toggle[self.stage] == false then
		overlay = "@disabled"
	else
		overlay = ""
	end
	self.currentImage = "images/" .. self.images[self.stage] .. ".png"
	self.ItemInstance.Icon = ImageReference:FromPackRelativePath(self.currentImage, overlay)
end

function MultiToggleItem:save()
	local saveData = {
		["stage"] = self.stage,
		["toggle"] = self.toggle
	}
	return saveData
end

function MultiToggleItem:load(data)
	if data ~= nil then
		self.stage = data["stage"]
		self.toggle = data["toggle"]
		self:updateIcon()
	end
	return true
end