ScriptHost:LoadScript("scripts/class.lua")
ScriptHost:LoadScript("scripts/custom_item.lua")
ScriptHost:LoadScript("scripts/ProgressiveToggle.lua")
ScriptHost:LoadScript("scripts/MultiToggle.lua")
ScriptHost:LoadScript("scripts/settings.lua")
local eldkeyImage = {"Eldstar"}
local eldkeyStages = {"Fortress0", "Fortress1", "Fortress2", "Fortress3", "Fortress4"}
local EldKeys = ProgressiveToggleItem("Eldstar + Fortress Keys", "EldKeys", 5, eldkeyImage, eldkeyStages)
local mamkeyImage = {"Mamar"}
local mamkeyStages = {"Ruins0", "Ruins1", "Ruins2", "Ruins3", "Ruins4"}
local MamKeys = ProgressiveToggleItem("Mamar + Ruins Keys", "MamKeys", 5, mamkeyImage, mamkeyStages)
local skokeyImage = {"Skolar"}
local skokeyStages = {"Tubba0", "Tubba1", "Tubba2", "Tubba3"}
local SkoKeys = ProgressiveToggleItem("Skolar + Tubba Castle Keys", "SkoKeys", 4, skokeyImage, skokeyStages)
local kleseedImage = {"Klevar"}
local kleseedStages = {"Seeds0", "Seeds1", "Seeds2", "Seeds3", "Seeds4"}
local KleSeeds = ProgressiveToggleItem("Klevar & Magical Seeds", "KleSeeds", 5, kleseedImage, kleseedStages)
local bluebImage = {"RedBerryOff", "RedBerry"}
local bluebs = {"BlueRightOff", "BlueRight", "BlueRight2"}
local Red2Bluebs = ProgressiveToggleItem("Red & 2 Blue Berries", "red2blueberries", 3, bluebImage, bluebs)
--local dojoImages = {"FirstDegree", "SecondDegree", "ThirdDegree", "FourthDegree", "Diploma"}
--local dojocard = MultiToggleItem("Dojo Degrees", "dojocard", dojoImages)
local partnerStages = {"", "Upgrade1", "Upgrade2"}
local goombarioImage = {"Goombario"}
local Goombario = ProgressiveToggleItem("Goombario", "goombario", 3, goombarioImage, partnerStages)
local kooperImage = {"Kooper"}
local Kooper = ProgressiveToggleItem("Kooper", "kooper", 3, kooperImage, partnerStages)
local bombetteImage = {"Bombette"}
local Bombette = ProgressiveToggleItem("Bombette", "bombette", 3, bombetteImage, partnerStages)
local parakarryImage = {"Parakarry"}
local Parakarry = ProgressiveToggleItem("Parakarry", "parakarry", 3, parakarryImage, partnerStages)
local bowImage = {"Bow"}
local Bow = ProgressiveToggleItem("Bow", "bow", 3, bowImage, partnerStages)
local wattImage = {"Watt"}
local Watt = ProgressiveToggleItem("Watt", "watt", 3, wattImage, partnerStages)
local sushiImage = {"Sushi"}
local Sushi = ProgressiveToggleItem("Sushi", "sushi", 3, sushiImage, partnerStages)
local lakilesterImage = {"Lakilester"}
local Lakilester = ProgressiveToggleItem("Lakilester", "lakilester", 3, lakilesterImage, partnerStages)
Tracker:AddItems("items/items.json")
Tracker:AddLayouts("layouts/tracker.json")
Tracker:AddLayouts("layouts/broadcast.json")
ScriptHost:LoadScript("scripts/autotracking.lua")