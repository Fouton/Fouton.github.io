-- Configuration --------------------------------------
AUTOTRACKER_ENABLE_DEBUG_LOGGING = false
-------------------------------------------------------
function autotracker_started()
    print("Autotracking Active")
    -- Invoked when the auto-tracker is activated/connected
end

U8_READ_CACHE = 0
U8_READ_CACHE_ADDRESS = 0

U16_READ_CACHE = 0
U16_READ_CACHE_ADDRESS = 0

gameActive = false

function InvalidateReadCaches()
    U8_READ_CACHE_ADDRESS = 0
    U16_READ_CACHE_ADDRESS = 0
end

function ReadU8(segment, address)
    if U8_READ_CACHE_ADDRESS ~= address then
        U8_READ_CACHE = segment:ReadUInt8(address)
        U8_READ_CACHE_ADDRESS = address        
    end

    return U8_READ_CACHE
end

function ReadU16(segment, address)
    if U16_READ_CACHE_ADDRESS ~= address then
        U16_READ_CACHE = segment:ReadUInt16(address)
        U16_READ_CACHE_ADDRESS = address        
    end

    return U16_READ_CACHE
end

function updateProgressiveItemFromBytes(segment, code, address, quantity)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = 0
        for i = 0, quantity-1, 1 do
            if ReadU8(segment, address+i) > 0 then
                value = value + 1
            end
        end
        if item.CurrentStage ~= value then
            print(item.Name .. ": " .. value)
            item.CurrentStage = value
        end
    end
end

function updateLetters(segment, address)
    local item = Tracker:FindObjectForCode("letters")
    if item then
        local value = 0
        for i = 0, 24, 1 do
            if ReadU8(segment, address+i) > 0 then
                value = value + 1
            end
        end
        if ReadU8(segment, address+26) > 0 then
            value = value + 1
        end
        if value > 3 then
            value = 3
        end
        if item.CurrentStage ~= value then
            print(item.Name .. ": " .. value)
            item.CurrentStage = value
        end
    end
end

function updateProgressiveToggleStateFromByte(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if value > 0 then
            if item.ItemState.toggle == false then
                print(item.Name .. " left object Obtained")
                item.ItemState.toggle = true
            end
        else
            item.ItemState.toggle = false
        end
        item.ItemState:updateIcon()
    end
end

function updateProgressiveToggleStateFromByteAndFlag(segment, code, address, flag)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        local flagTest = value & flag
        if flagTest ~= 0 then
            if item.ItemState.toggle == false then
                print(item.Name .. " left object Obtained")
                item.ItemState.toggle = true
            end
        else
            item.ItemState.toggle = false
        end
        item.ItemState:updateIcon()
    end
end

function updateProgressiveToggleStageFromBytes(segment, code, address, quantity)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = 0
        for i = 0, quantity-1, 1 do
            if ReadU8(segment, address+i) > 0 then
                value = value + 1
            end
        end
        if item.ItemState.stage ~= value+1 then
            print(item.Name .. ": " .. value)
            item.ItemState.stage = value+1
            item.ItemState:updateIcon()
        end
    end
end

function updateProgressiveToggleStageFromByte(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if item.ItemState.stage ~= value+1 then
            print(item.Name .. ": " .. value)
            item.ItemState.stage = value+1
            item.ItemState:updateIcon()
        end
    end
end

function updateProgressiveItemFromByte(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if item.ItemState.stage ~= value then
            print(item.Name .. ": " .. value)
            item.CurrentStage = value
        end
    end
end

function updateToggleItemFromByte(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if value > 0 then
            if item.Active == false then
                print(item.Name .. " obtained")
                item.Active = true
            end
        else
            item.Active = false
        end
    end
end

function updateToggleItemFromByteAndFlag(segment, code, address, flag)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if value & flag ~= 0 then
            if item.Active == false then
                print(item.Name .. " obtained")
                item.Active = true
            end
        else
            item.Active = false
        end
    end
end
function updateGameStatus(segment, address)
    local value = ReadU8(segment, address)
    if value == 1 then
        gameActive = true
    else
        gameActive = false
    end
end

function updateKeyItems(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        updateGameStatus(segment,0x80356c07)
        if gameActive then
            updateToggleItemFromByte(segment,"ultrastone",0x80356c0f)
            updateToggleItemFromByte(segment,"pulsestone",0x80356c12)
            updateToggleItemFromByte(segment,"palacekey",0x80356c14)
            updateToggleItemFromByte(segment,"lunarstone",0x80356c15)
            updateToggleItemFromByte(segment,"pyramidstone",0x80356c16)
            updateToggleItemFromByte(segment,"diamondstone",0x80356c17)
            updateToggleItemFromByte(segment,"shell",0x80356c19)
            --Castle Key Solo?
            updateToggleItemFromByte(segment,"weight",0x80356c1c)
            updateToggleItemFromByte(segment,"boosportrait",0x80356c1d)
            updateToggleItemFromByte(segment,"crystalberry",0x80356c1e)
            updateToggleItemFromByte(segment,"storeroom",0x80356c20)
            updateToggleItemFromByte(segment,"toytrain",0x80356c21)
            updateToggleItemFromByte(segment,"record",0x80356c22)
            updateToggleItemFromByte(segment,"fryingpan",0x80356c23)
            updateToggleItemFromByte(segment,"dictionary",0x80356c24)
            updateToggleItemFromByte(segment,"cookbook",0x80356c29)
            updateToggleItemFromByte(segment,"jaderaven",0x80356c2a)
            updateProgressiveToggleStageFromBytes(segment, "KleSeeds", 0x80356c2b, 4)
            updateToggleItemFromByte(segment,"calculator",0x80356c30)
            updateToggleItemFromByte(segment,"bucket",0x80356c31)
            updateToggleItemFromByte(segment,"scarf",0x80356c32)
            updateToggleItemFromByte(segment,"redkey",0x80356c33)
            updateToggleItemFromByte(segment,"bluekey",0x80356c34)
            updateLetters(segment, 0x80356c36)
            updateToggleItemFromByte(segment,"artifact",0x80356c53)
            updateToggleItemFromByte(segment,"dolly",0x80356c56)
            updateToggleItemFromByte(segment,"waterstone",0x80356c57)
            updateToggleItemFromByte(segment,"magicalbean",0x80356c58)
            updateToggleItemFromByte(segment,"fertilesoil",0x80356c59)
            updateToggleItemFromByte(segment,"miraclewater",0x80356c5a)
            updateToggleItemFromByte(segment,"volcanovase",0x80356c5b)
            updateToggleItemFromByte(segment,"lyrics",0x80356c67)
            updateToggleItemFromByte(segment,"melody",0x80356c68)
            updateToggleItemFromByte(segment,"mailbag",0x80356c69)
            updateToggleItemFromByte(segment,"oddkey",0x80356c6b)
            updateToggleItemFromByte(segment,"starstone",0x80356c6c)
            updateToggleItemFromByte(segment,"warehouse",0x80356c79) 
            updateProgressiveToggleStageFromBytes(segment, "EldKeys", 0x80356d6d, 4)
            updateProgressiveToggleStageFromBytes(segment, "MamKeys", 0x80356d71, 4)
            updateProgressiveToggleStageFromBytes(segment, "SkoKeys", 0x80356d75, 3)
            updateProgressiveItemFromBytes(segment, "bowserkey", 0x80356d78, 5)
            updateProgressiveItemFromBytes(segment, "prisonkey", 0x80356d7d, 2)
            updateProgressiveToggleStageFromBytes(segment, "red2blueberries", 0x80356d80, 2)
            updateProgressiveToggleStateFromByte(segment, "red2blueberries", 0x80356d82)
            updateToggleItemFromByte(segment,"yellowberry",0x80356d83)
            updateToggleItemFromByte(segment,"purpleberry",0x80356d84) 
        end
    end
end

function updatePartners(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING and gameActive then
        updateProgressiveToggleStateFromByte(segment, "goombario", 0x8010f2ae)
        updateProgressiveToggleStageFromByte(segment, "goombario", 0x8010f2ad)
        updateProgressiveToggleStateFromByte(segment, "kooper", 0x8010f2b6)
        updateProgressiveToggleStageFromByte(segment, "kooper", 0x8010f2b5)
        updateProgressiveToggleStateFromByte(segment, "bombette", 0x8010f2be)
        updateProgressiveToggleStageFromByte(segment, "bombette", 0x8010f2bd)
        updateProgressiveToggleStateFromByte(segment, "parakarry", 0x8010f2c6)
        updateProgressiveToggleStageFromByte(segment, "parakarry", 0x8010f2c5)
        updateProgressiveToggleStateFromByte(segment, "bow", 0x8010f2ee)
        updateProgressiveToggleStageFromByte(segment, "bow", 0x8010f2ed)
        updateProgressiveToggleStateFromByte(segment, "sushi", 0x8010f2de)
        updateProgressiveToggleStageFromByte(segment, "sushi", 0x8010f2dd)
        updateProgressiveToggleStateFromByte(segment, "watt", 0x8010f2d6)
        updateProgressiveToggleStageFromByte(segment, "watt", 0x8010f2d5)
        updateProgressiveToggleStateFromByte(segment, "lakilester", 0x8010f2e6)
        updateProgressiveToggleStageFromByte(segment, "lakilester", 0x8010f2e5)
    end
end

function updateEquipment(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING and gameActive then
        updateProgressiveItemFromByte(segment,"boots",0x8010f290)
        updateProgressiveItemFromByte(segment,"hammer",0x8010f291)
    end
end

function updateChapters(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING and gameActive then
        updateProgressiveToggleStateFromByteAndFlag(segment, "EldKeys", 0x80357017, 0x02)
        updateProgressiveToggleStateFromByteAndFlag(segment, "MamKeys", 0x80357017, 0x04)
        updateProgressiveToggleStateFromByteAndFlag(segment, "SkoKeys", 0x80357017, 0x08)
        updateToggleItemFromByteAndFlag(segment, "muskular", 0x80357017, 0x10)
        updateToggleItemFromByteAndFlag(segment, "misstar", 0x80357017, 0x20)
        updateProgressiveToggleStateFromByteAndFlag(segment, "KleSeeds", 0x80357017, 0x40)
        updateToggleItemFromByteAndFlag(segment, "kalmar", 0x80357017, 0x80)
    end
end

-- Run the in-game status check more frequently (every 250ms) to catch save/quit scenarios more effectively
ScriptHost:AddMemoryWatch("Key Items", 0x80356c00, 0x185, updateKeyItems, 250)
ScriptHost:AddMemoryWatch("Partners", 0x8010f2ad, 0x42, updatePartners, 250)
ScriptHost:AddMemoryWatch("Equipment", 0x8010f290, 0x02, updateEquipment, 250)
ScriptHost:AddMemoryWatch("Chapters", 0x80357017, 0x01, updateChapters, 250)
