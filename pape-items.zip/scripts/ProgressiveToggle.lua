ProgressiveToggleItem = CustomItem:extend()

function ProgressiveToggleItem:init(name, code, stages, image, overlays)
	self:createItem(name) 
	self.code = code
    self:setProperty("active", true)
	self.images = image
	self.currentImage = "images/" .. image[1] .. ".png"
	self.currentOverlay = "@disabled, overlay|images/" .. overlays[1] .. ".png"
	self.stages = stages
	self.stage = 1
	self.toggle = false
	self.ItemInstance.PotentialIcon = ImageReference:FromPackRelativePath(self.currentImage, self.currentOverlay)
	self.overlays = overlays
	self:updateIcon()
end

function ProgressiveToggleItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function ProgressiveToggleItem:providesCode(code)
    if code == self.code then
        return 1
    end
    return 0
end

function ProgressiveToggleItem:onLeftClick()
	if self.toggle then
		self.toggle = false
	else
		self.toggle = true
	end
	self:updateIcon()
end

function ProgressiveToggleItem:onRightClick()
	if self.stage < self.stages then
		self.stage = self.stage + 1
	else
		self.stage = 1
	end
	self:updateIcon()
end

function ProgressiveToggleItem:updateIcon()
	local text = "overlay|images/"
	if self.toggle == false and #self.images == 1 then
		text = "@disabled, " .. text .. ""
	end
	if #self.images == 2 and self.toggle then
		self.currentImage = "images/" .. self.images[2] .. ".png"
	else
		self.currentImage = "images/" .. self.images[1] .. ".png"
	end
	text = text .. "" .. self.overlays[self.stage] .. ".png"
	self.ItemInstance.Icon = ImageReference:FromPackRelativePath(self.currentImage, text)
end

function ProgressiveToggleItem:save()
	local saveData = {
		["stage"] = self.stage,
		["toggle"] = self.toggle
	}
	return saveData
end

function ProgressiveToggleItem:load(data)
	if data ~= nil then
		self.stage = data["stage"]
		self.toggle = data["toggle"]
		self:updateIcon()
	end
	return true
end