-- Configuration --------------------------------------
AUTOTRACKER_ENABLE_DEBUG_LOGGING = false
-------------------------------------------------------
function autotracker_started()
    print("Autotracking Active")
    -- Invoked when the auto-tracker is activated/connected
end

-- Thanks to https://cloudmodding.com/zelda/oot for most addresses
-- Thanks to coavin's autotracking fork of Hamsda's pack for the is-in-game & quest addresses

U8_READ_CACHE = 0
U8_READ_CACHE_ADDRESS = 0

U16_READ_CACHE = 0
U16_READ_CACHE_ADDRESS = 0

gameActive = false

function InvalidateReadCaches()
    U8_READ_CACHE_ADDRESS = 0
    U16_READ_CACHE_ADDRESS = 0
end

function ReadU8(segment, address)
    if U8_READ_CACHE_ADDRESS ~= address then
        U8_READ_CACHE = segment:ReadUInt8(address)
        U8_READ_CACHE_ADDRESS = address        
    end

    return U8_READ_CACHE
end

function ReadU16(segment, address)
    if U16_READ_CACHE_ADDRESS ~= address then
        U16_READ_CACHE = segment:ReadUInt16(address)
        U16_READ_CACHE_ADDRESS = address        
    end

    return U16_READ_CACHE
end

function updateProgressiveItemFromBytes(segment, code, address, quantity)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = 0
        for i = 0, quantity-1, 1 do
            if ReadU8(segment, address+i) > 0 then
                value = value + 1
            end
        end
        if item.CurrentStage ~= value then
            print(item.Name .. ": " .. value)
            item.CurrentStage = value
        end
    end
end

function updateProgressiveItemFromByte(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if item.ItemState.stage ~= value then
            print(item.Name .. ": " .. value)
            item.CurrentStage = value
        end
    end
end

function updateToggleItemFromByte(segment, code, address)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if value > 0 and value < 255 then
            if item.Active == false then
                print(item.Name .. " obtained")
                item.Active = true
            end
        else
            item.Active = false
        end
    end
end

function updateToggleItemFromByteAndFlag(segment, code, address, flag)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if value & flag ~= 0 then
            if item.Active == false then
                print(item.Name .. " obtained")
                item.Active = true
            end
        else
            item.Active = false
        end
    end
end

function updateProgressiveItemFromByteAndFlags(segment, code, address, flag1, flag2)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if value & flag1 ~= 0 and value & flag2 ~= 0 then
            if item.CurrentStage ~= 3 then
                print(item.Name .. " obtained")
                item.CurrentStage = 3
            end
        elseif value & flag2 ~= 0 then
            if item.CurrentStage ~= 2 then
                print(item.Name .. " obtained")
                item.CurrentStage = 2
            end
        elseif value & flag1 ~= 0 then
            if item.CurrentStage ~= 1 then
                print(item.Name .. " obtained")
                item.CurrentStage = 1
            end
        else
            item.CurrentStage = 0
        end
    end
end

function updateHookshot(segment, address)
    local item = Tracker:FindObjectForCode("hookshot")
    if item then
        local value = ReadU8(segment, address)
        if value == 11 then
            if item.CurrentStage ~= 2 then
                print("Longshot obtained")
                item.CurrentStage = 2
            end
        elseif value == 10 then
            if item.CurrentStage ~= 1 then
                print("Hookshot obtained")
                item.CurrentStage = 1
            end
        else
            item.CurrentStage = 0
        end
    end
end

function updateOcarina(segment, address)
    local item = Tracker:FindObjectForCode("ocarina")
    if item then
        local value = ReadU8(segment, address)
        if value == 8 then
            if item.CurrentStage ~= 2 then
                print("Ocarina of Time obtained")
                item.CurrentStage = 2
            end
        elseif value == 7 then
            if item.CurrentStage ~= 1 then
                print("Ocarina obtained")
                item.CurrentStage = 1
            end
        else
            item.CurrentStage = 0
        end
    end
end

function updateBottle(segment, address)
    local item = Tracker:FindObjectForCode("rupo")
    local ruto = false
    local poe = false
    if item then
        for i = 0, 3, 1 do
            local value = ReadU8(segment, address + i)
            if value == 0x1B then
                ruto = true
            elseif value == 0x1E then
                poe = true
            end
        end
        local value = ReadU8(segment, address)
        if poe and item.ItemState.rightStage == 0 then
            item.ItemState.rightStage = 1
            print("Big Poe obtained")
        end
        if ruto and item.ItemState.leftStage < 2 then
            print("Ruto's Letter obtained")
            item.ItemState.leftStage = 2
        elseif value > 0 and value < 255 then
            if item.ItemState.leftStage == 0 then
                print("Bottle obtained")
                item.ItemState.leftStage = 1
                item.ItemState:updateIcon()
            end
        elseif item.ItemState.leftStage ~= 3 then
            item.ItemState.leftStage = 0
        end
        item.ItemState:updateIcon()
    end
end

function updateAdultTrade(segment, address)
    local item = Tracker:FindObjectForCode("adulttrade")
    if item then
        local value = ReadU8(segment, address)
        if value > 0 and value < 255 then
            value = value - 0x2D + 1
            if item.CurrentStage ~= value then
                print ("Adult Quest Chain now at stage " .. value)
                item.CurrentStage = value
            end
        else
            item.CurrentStage = 0
        end
    end
end

function updateChildTrade(segment, address)
    local item = Tracker:FindObjectForCode("childtrade")
    if item then
        local value = ReadU8(segment, address)
        if value > 0x27 and value < 255 then
            if item.CurrentStage ~= value then
                print ("Child Quest Chain now at stage " .. value)
                item.CurrentStage = 8
            end
        elseif value > 0 and value < 255 then
            value = value - 0x20
            if item.CurrentStage ~= value then
                print ("Child Quest Chain now at stage " .. value)
                item.CurrentStage = value
            end
        else
            item.CurrentStage = 0
        end
    end
end

-- Should return true if the information currently stored in RAM should be used
-- to update the tracker. Return false on title screen, etc.
-- Directly taken from Coavin's LUA scripting.
function isInGame()
    --[[ 8011B92C is game mode:     8011A5EC is validation string:
        0 is normal gameplay        reads ZELDAZ if a file is loaded
        1 is title screen
        2 is file select
        3 is horseback game     ]]
    local gameMode = AutoTracker:ReadU8(0x8011B92F)
    -- game mode indicates normal play
    if gameMode ~= 0 and gameMode ~= 3 then
      return false
    -- validation string is not present, no file is loaded
    elseif AutoTracker:ReadU8(0x8011A5EC) == 0 then
      return false
    -- we must be in game, so RAM is safe to read
    else
      return true
    end
  end

function updateMostItems(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING and isInGame() then
        updateToggleItemFromByte(segment,"firearrows",0x8011a648)
        updateToggleItemFromByte(segment,"dinsfire",0x8011a649)
        updateOcarina(segment, 0x8011a64b)
        updateToggleItemFromByte(segment,"bombchu",0x8011a64c)
        updateHookshot(segment, 0x8011a64d)
        updateToggleItemFromByte(segment,"icearrows",0x8011a64e)
        updateToggleItemFromByte(segment,"faroreswind",0x8011a64f)
        updateToggleItemFromByte(segment,"boomerang",0x8011a650)
        updateToggleItemFromByte(segment,"lensoftruth",0x8011a651)
        updateToggleItemFromByte(segment,"hammer",0x8011a653)
        updateToggleItemFromByte(segment,"lightarrows",0x8011a654)
        updateToggleItemFromByte(segment,"nayruslove",0x8011a655)
        updateBottle(segment, 0x8011a656)
        updateAdultTrade(segment, 0x8011a65a)
        updateChildTrade(segment, 0x8011a65b)
    end
end

function updateEquipment(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING and isInGame() then
        updateToggleItemFromByteAndFlag(segment, "gorontunic", 0x8011a66c, 0x02)
        updateToggleItemFromByteAndFlag(segment, "zoratunic", 0x8011a66c, 0x04)
        updateToggleItemFromByteAndFlag(segment, "ironboots", 0x8011a66c, 0x20)
        updateToggleItemFromByteAndFlag(segment, "hoverboots", 0x8011a66c, 0x40)
        updateToggleItemFromByteAndFlag(segment, "kokirisword", 0x8011a66d, 0x01)
        --updateToggleItemFromByteAndFlag(segment, "mastersword", 0x8011a66d, 0x02)
        updateToggleItemFromByteAndFlag(segment, "biggoronsword", 0x8011a66d, 0x04)
        updateToggleItemFromByteAndFlag(segment, "hylianshield", 0x8011a66d, 0x20)
        updateToggleItemFromByteAndFlag(segment, "mirrorshield", 0x8011a66d, 0x40)
    end
end

function updateCapacities(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING and isInGame() then
        --updateProgressiveItemFromByteAndFlags(segment, "dekusticks", 0x8011a671, 0x02, 0x04, 0x08)
        --updateProgressiveItemFromByteAndFlags(segment, "dekunuts", 0x8011a671, 0x10, 0x20)--, 0x30)
        updateProgressiveItemFromByteAndFlags(segment, "scales", 0x8011a672, 0x02, 0x04)--, 0x06)
        --updateProgressiveItemFromByteAndFlags(segment, "wallet", 0x8011a672, 0x10, 0x20)--, 0x30)
        updateProgressiveItemFromByteAndFlags(segment, "slingshot", 0x8011a672, 0x40, 0x80)--, 0xC0)
        updateProgressiveItemFromByteAndFlags(segment, "bow", 0x8011a673, 0x01, 0x02)--, 0x03)
        updateProgressiveItemFromByteAndFlags(segment, "bombs", 0x8011a673, 0x08, 0x10)--, 0x18)
        updateProgressiveItemFromByteAndFlags(segment, "gloves", 0x8011a673, 0x40, 0x80)--, 0xC0)
        --updateToggleItemFromByteAndFlag(segment, "gerudo", 0x8011a675, 0x40)
        --updateToggleItemFromByteAndFlag(segment, "agony", 0x8011a675, 0x20)
        updateToggleItemFromByteAndFlag(segment, "storm", 0x8011a675, 0x02)
        updateToggleItemFromByteAndFlag(segment, "time", 0x8011a675, 0x01)
        updateToggleItemFromByteAndFlag(segment, "zelda", 0x8011a676, 0x10)
        updateToggleItemFromByteAndFlag(segment, "epona", 0x8011a676, 0x20)
        updateToggleItemFromByteAndFlag(segment, "saria", 0x8011a676, 0x40)
        updateToggleItemFromByteAndFlag(segment, "sun", 0x8011a676, 0x80)
        updateToggleItemFromByteAndFlag(segment, "serenade", 0x8011a676, 0x01)
        updateToggleItemFromByteAndFlag(segment, "requiem", 0x8011a676, 0x02)
        updateToggleItemFromByteAndFlag(segment, "nocturne", 0x8011a676, 0x04)
        updateToggleItemFromByteAndFlag(segment, "prelude", 0x8011a676, 0x08)
        updateToggleItemFromByteAndFlag(segment, "minuet", 0x8011a677, 0x40)
        updateToggleItemFromByteAndFlag(segment, "bolero", 0x8011a677, 0x80)
    end
end

function updateMagic(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING and isInGame() then
        updateProgressiveItemFromByteAndFlags(segment, "magic", 0x8011a602, 0x01, 0x02)
    end
end

function updateSkulltula(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING and isInGame() then
        local value = ReadU8(segment, 0x8011a6a1)
        local item = Tracker:FindObjectForCode("skulltula")
        if value < 101 then
            item.CurrentStage = value
        end
    end
end

-- Run the in-game status check more frequently (every 250ms) to catch save/quit scenarios more effectively
ScriptHost:AddMemoryWatch("Items", 0x8011A648, 0x14, updateMostItems, 250)
ScriptHost:AddMemoryWatch("Equipment", 0x8011A66C, 0x02, updateEquipment, 250)
ScriptHost:AddMemoryWatch("Capacity", 0x8011A671, 0x07, updateCapacities, 250)
ScriptHost:AddMemoryWatch("Magic", 0x8011A602, 0x01, updateMagic, 250)
ScriptHost:AddMemoryWatch("Skulltula", 0x8011A6A1, 0x01, updateSkulltula, 250)