local bottle = "images/0026.png"
local offBottle = "images/0027.png"
local offPurpBottle = "images/0027c.png"
local ruto = "images/ruto.png"

local overlayPurpBot = "overlay|images/purpleBottle.png"
local overlayCheckPurp = "overlay|images/checkPurp.png"
local overlayCheckGreen = "overlay|images/checkGreen.png"
local overlayPurpBotCheckGreen = "overlay|images/purpleBottle.png, overlay|images/checkGreen.png"
local overlayCheckBoth = "overlay|images/checkGreen.png, overlay|images/checkPurp.png"

Rupo = class(CustomItem)

function Rupo:init(name, code)
	self:createItem(name) 
	self.code = code
    self:setProperty("active", true)
	self.currentImage = offBottle
	self.ItemInstance.PotentialIcon = ImageReference:FromPackRelativePath(self.currentImage)
	self.currentOverlay = ""
	self.leftStage = 0
	self.rightStage = 0
	self:updateIcon()
end

function Rupo:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function Rupo:providesCode(code)
    if code == self.code then
        return 1
    end
    return 0
end

function Rupo:onLeftClick()
	if self.leftStage < 3 then
		self.leftStage = self.leftStage + 1
	else
		self.leftStage = 0
	end
	self:updateIcon()
end

function Rupo:onRightClick()
	if self.rightStage < 2 then
		self.rightStage = self.rightStage + 1
	else
		self.rightStage = 0
	end
	self:updateIcon()
end

function Rupo:updateIcon()
	if self.leftStage == 0 then
		self.currentImage = offBottle
	elseif self.leftStage == 1 then
		self.currentImage = bottle
	elseif self.leftStage == 2 then
		self.currentImage = ruto
	elseif self.leftStage == 3 then
		self.currentImage = ruto
	end

	if self.leftStage < 3 then
		if self.rightStage == 0 then
			self.currentOverlay = ""
		elseif self.rightStage == 1 then
			self.currentOverlay = overlayPurpBot
		else
			self.currentOverlay = overlayCheckPurp
		end
	else
		if self.rightStage == 0 then
			self.currentOverlay = overlayCheckGreen
		elseif self.rightStage == 1 then
			self.currentOverlay = overlayPurpBotCheckGreen
		else
			self.currentOverlay = overlayCheckBoth
		end
	end
	self.ItemInstance.Icon = ImageReference:FromPackRelativePath(self.currentImage, self.currentOverlay)
end

function Rupo:save()
	local saveData = {
		["left"] = self.leftStage,
		["right"] = self.rightStage,
	}
	return saveData
end

function Rupo:load(data)
	if data ~= nil then
		self.leftStage = data["left"]
		self.rightStage = data["right"]
		self:updateIcon()
	end
	return true
end