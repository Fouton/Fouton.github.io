Autotracking:
BIZHAWK REQUIRED

(Note this google doc is for Paper Mario but its the same thing)
Google Docs README version: https://docs.google.com/document/d/1vtY18F3MdYuxy7ehbFfZEhUfZ_cbPvfetpY138Waabs/
Go to this link if you prefer font formatting


Recommended Setup:
Step 1: Download and run this prereq - https://github.com/TASVideos/BizHawk-Prereqs/releases
Step 2: Download Bizhawk 2.4 - https://github.com/TASEmulators/BizHawk/releases/tag/2.4
Step 3: Bizhawk Settings:
REQUIRED: In Config > Customize > Advanced, make sure the bottom tickbox is set to Lua+LuaInterface
OPTIONAL: N64 > Use Expansion Slot (this is just for other games, like Paper Mario, but it doesnt interfere)
OPTIONAL: Make sure your core (on the bottom) says Mupen64Plus, and when you go to N64 > Plugins, make sure its set to GLideN64 (this is also optional, but Mupen64Plus is the most reliable core, especially for other games)

Once youve done these options, go to Emulation > Reboot Core

OPTIONAL: Full Config Setup - you can use this ZOOTR guide for setting up bizhawk to make sure the game runs well: https://wiki.ootrandomizer.com/index.php?title=Bizhawk

Step 4: Now that youre setup: Run the rom in bizhawk, and the emotracker pack. In emotracker, right click the robot, N64 > Lua. It will go yellow, and thats okay for now.
Step 5: In Bizhawk, go to Tools > Lua Console. In the window popup, click the yellow folder. From here, you need to navigate to EmoTracker's install folder (not the documents one) which is likely C:/ProgramFiles(x86)/EmoTracker/ then from here, select /Connectors/Bizhawk/connector.lua
Step 6: Double Click the Red Stop square. Your connection should establish, and your autotracker should go teal. Note that you can do steps 4 or 5+6 in either order, and it will still work. So if your tracker crashes or needs a restart, it will freeze your game while the connection hangs, but once you restart the tracker's lua connection (right click robot > Start, or N64 > lua if its not an option) it will work again



Newer Bizhawk Versions (2.6.1)
If you prefer a newer version of bizhawk for some reason (I still play on 2.3.1, so you shouldnt need it) you can download CrowdControl and use the ROM Setup to install the latest Bizhawk they support (2.6.1 atm) and that will function as well, if you use their supported Connector Lua. To get this, you have to go download the SDK here: https://crowd-control-sdk.s3.amazonaws.com/SDK.7z. Then follow the steps above from Step 3 onward. Replace the connector.lua used in Step 5 with the ConnectorScripts/connector.lua you just DL'd in the SDK

If this isn't good enough, you can join EmoTracker's discord, and try to get some help in the #autotracker-support channel. Please note: Autotracking will soon undergo a change, so you'll probably get limited help beyond basic tech support.